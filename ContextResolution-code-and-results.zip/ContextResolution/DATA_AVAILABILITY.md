# Data and code availability

## Statement for the manuscript

The experiments use Cityscapes and ADE20K, which are available from their official providers at <https://www.cityscapes-dataset.com/> and <https://ade20k.csail.mit.edu/>, subject to their respective registration, access and licensing conditions. We do not redistribute the original benchmark images or annotations. The study implementation, experimental configurations, available raw logs, per-run and per-class results, profiling records, analysis scripts, and qualitative prediction masks are deposited in the accompanying public code repository. The repository also records the image identifiers, crop coordinates and inference protocol used for the qualitative comparisons. Trained checkpoints are not included in this release; their recorded hashes are provided where available.

Public repository: <https://github.com/zxh135200/ContextResolution>. The project is presented as **ContextResolution**, matching the manuscript title. Use the current repository URL and a fixed release/commit identifier in the manuscript; no archival DOI is claimed.

## Access conditions

| Material | Access |
|---|---|
| Cityscapes originals and annotations | Official provider; registration and dataset license apply |
| ADE20K images and annotations | Official provider; provider and image-rights conditions apply |
| Study code and configurations | This repository; third-party license exceptions are listed separately |
| Raw experiment logs and numerical source data | This repository, with immutable content hashes |
| Qualitative prediction masks, image list and crop metadata | This repository; original benchmark imagery is obtained separately |
| Trained checkpoints | Not distributed in this release; no public download URL is claimed |

Cityscapes terms: <https://www.cityscapes-dataset.com/license/>.

ADE20K terms: <https://ade20k.csail.mit.edu/terms/>.

Public access to a benchmark does not imply permission to mirror its original files. In particular, the Cityscapes dataset license restricts redistribution, and ADE20K image rights are not owned by the dataset maintainers.

## Journal context

The target journal is **Pattern Recognition**. The relevant guide is <https://www.sciencedirect.com/journal/pattern-recognition/publish/guide-for-authors> and Elsevier's research-data guidance is <https://www.elsevier.com/researcher/author/tools-and-resources/research-data>. The journal-specific guide could not be retrieved automatically on 21 October 2026 (HTTP 403); this document does not certify the journal's current repository/DOI requirements. The corresponding author should use the actual submission instructions and cite the published repository, rather than promise future public access.
