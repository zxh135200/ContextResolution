# Qualitative Cityscapes reproduction

The release includes 45 real full-resolution trainId prediction masks (`uint8`, IDs 0–18), a frozen 15-image list, five GT-based scene categories, identical 512×384 crop coordinates, exact inference settings and checkpoint hashes. There are no generated or manually painted segmentation results.

The compared checkpoints are `1111` seed0, `4311` seed0 and `8311` seed2, trained for 160k iterations. They are illustrative single-checkpoint examples, not a matched-seed causal comparison. Images are selected for small objects, thin structures, crowded scenes, distant objects and contextual complexity, with one case per category per validation city.

## Recreate panels from saved predictions

Provide your own authorized Cityscapes copy:

```bash
python scripts/prepare_qualitative.py --cityscapes-root /absolute/path/to/cityscapes --out generated/qualitative
python scripts/render_qualitative.py --base generated/qualitative --output-dir generated/qualitative_figures
```

Preparation verifies the original RGB and provided labelTrainIds against the archived hashes. If your labelTrainIds differ, it fails with a clear message rather than silently substituting a different evaluation target. Dataset files and rendered panels remain under the ignored `generated/` folder. The released masks alone are sufficient for inspecting model outputs, but reproducing the original/GT columns requires benchmark access.

## Repeat model inference

Matching weights must be supplied separately. Place the original full checkpoints at `/path/to/checkpoints/1111.pth`, `4311.pth`, `8311.pth`:

```bash
python scripts/predict_cityscapes.py --base generated/qualitative --checkpoint-dir /path/to/checkpoints
```

The script checks checkpoint hashes, loads the state dictionary strictly, and applies the recorded FP32, single-scale 2048×1024, no-flip, 768×768 sliding-window/stride256 protocol. It records confusion matrices and per-image outputs. The computed 15-scene subset scores must not be presented as Cityscapes full-validation scores.

If the matching weights are unavailable, the saved masks and figure preparation still work. Checkpoint hashes do not enable reconstruction of deleted weights. A new training run produces a new checkpoint with its own provenance and may not reproduce the saved masks bit-for-bit.
