# Source selection and statistical limits

The canonical tables use the authors' previously submitted source archive for existing target/proxy evidence, together with the newly completed target-lattice records. Source filenames and SHA-256 values are linked in `provenance/raw_source_index.json` and `results/experiment_index.csv`.

## The two 4211 records

For nominal labels 3 and 4, the earlier submitted archive reports final mIoU **80.61** and **80.69**. Alternative same-labelled server logs reported **80.88** and **79.77**; the cause of this disagreement has not been established. The public canonical tables retain the earlier submitted archive's 80.61 and 80.69, and their exact original raw logs are included. This source choice is not evidence that the conflicting historical logs have been explained.

The selected 4211 sequence is `80.56, 80.87, 80.40, 80.61, 80.69`; its five-repeat mean is `80.626` and population standard deviation is `0.15447977213861955`. The main analysis and figures use these values consistently.

## Seeds and fidelity

The fields `nominal_seed` and `actual_seed` are retained separately. Each principal target policy has five distinct actual seeds, but 33 of the 50 target labels differ from the logged random seed. The repetitions are not a fully matched seed design across policies. The ranking/correlation and shortlist calculations are policy-level retrospective descriptions; they do not establish causal superiority or statistical significance from paired repeats.

The 8k proxy and 160k target analyses use the same nine-policy lattice and exclude the `1111` control from the nine-policy ranking correlation. `ddof=0` is used throughout. The regret is the observed score gap between the best target policy and the best target policy within the proxy-selected shortlist.

## Per-class and qualitative evidence

The main 19-class results are extracted from the selected final full-validation logs. They are not a new re-evaluation of every historical checkpoint. `1111` and `4311` visualization checkpoints were obtained in supplementary training runs and are not substituted into the main five-repeat statistics. Their full-validation scores are 80.94 and 80.70; the selected `8311` checkpoint has a full-validation score of 80.80. One checkpoint per policy is used for illustration.

The 15 qualitative scenes and crops were fixed using GT-annotation criteria before looking at predictions. The provided trainId GT differs slightly from canonical labelId conversion in some images; the original validation-target trainIds were used consistently. Per-image differences are recorded in `qualitative/selection.json`. Metrics on the selected 15 images are not the full 500-image Cityscapes benchmark.

## Resource measurements

Resource comparisons use the archived common RTX 4090 FP32 protocol: 768×768 input, batch size 1, `encode_decode`, 50 warm-up iterations, 200 timed iterations, three trials, and CUDA synchronization. `fvcore_GFLOPs` is the partial operator count reported by fvcore; it is not a MAC count and excludes unsupported operations. Memory/latency numbers describe this protocol, not end-to-end Cityscapes sliding-window inference or training peak memory.
