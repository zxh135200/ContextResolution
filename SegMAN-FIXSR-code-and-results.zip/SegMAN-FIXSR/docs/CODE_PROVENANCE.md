# Code provenance

The runtime is based on [the official SegMAN repository](https://github.com/yunxiangfu2001/SegMAN) at commit `ac606438a87d4c4d4b48064df844c86dfbd59958`, which matches the revision recorded in the authors' original reproducibility package. The complete segmentation runtime and selective-scan kernel sources are included. This study does not claim authorship of the original SegMAN, MMSegmentation, SegFormer, NATTEN or Mamba/VMamba components.

The segmentation backbone and study audit/profiling tools come from the previously submitted study archive, SHA-256 `319cbd10885f6527ed5147c0777d6346c26d2f868512bfdf67ac10025a9d64e1`. The backbone distributed there was identical in the `01_code` and `segmentation` locations. Imported study files have a modification notice and normalized source-code line endings. Their original and distributed checksums are recorded in `provenance/code.json`. Original raw logs/configuration evidence is byte-identical and is not normalized.

The FIXSR implementation applies the configured stage reductions to the relevant feature/KV paths and restores spatial resolution where required. The same archived backbone also contains the existing optional LINKSR coupling and diagnostic switches; the FIXSR lattice configurations disable these. There are no newly trained architectures in this release.

Portable experiment configurations are derived from the **effective configuration blocks printed in the raw logs**, not from filename assumptions. They make dataset/pretrained paths configurable, use the logged actual seed, clear machine-specific resume paths, and omit shared-device memory-reservation hooks. These infrastructure adaptations do not change the optimizer, learning-rate schedule, model parameters or augmentation settings. Original configurations and effective log blocks remain available for audit.

The shell queues, SSH access helpers, private platform connection files and development backups used on the authors' machines are not runtime dependencies and are not distributed.
