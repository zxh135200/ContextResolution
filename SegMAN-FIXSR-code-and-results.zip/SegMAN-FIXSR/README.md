# SegMAN-FIXSR

Reproducibility materials for the SegMAN spatial-reduction study. The original experimental archive is titled **Budget-Conditioned and Stability-Aware Spatial-Reduction Policy Selection for Semantic Segmentation**; manuscript presentation may be revised separately.

The study selects stage-wise spatial-reduction policies under a fixed training budget. For the Cityscapes target lattice, `s1 ∈ {4,6,8}`, `s2 ∈ {2,3,4}`, and stages 3–4 are fixed to 1. `1111` is the unreduced control. The backbone is based on [SegMAN](https://github.com/yunxiangfu2001/SegMAN), not an architecture introduced by this repository.

## Included evidence

| Experiment | Available records |
|---|---:|
| SegMAN Cityscapes, 160k iterations | 50: nine policies plus control, five repeats each |
| SegMAN Cityscapes, 8k proxy budget | 45: nine policies, five repeats each |
| SegFormer-B0 Cityscapes, 8k transfer | 6: `8421` and `6221`, three repeats each |
| SegMAN ADE20K, 160k iterations | 9: `4311`, `6211`, `8411`, three repeats each |
| Cityscapes qualitative predictions | 45 masks: 15 fixed scenes × `1111`, `4311`, `8311` |

Raw training/evaluation logs, original configurations, historical ablations, training-curve records, and profiling outputs are retained under `evidence/`. Identical files are stored once by SHA-256; `provenance/raw_source_index.json` maps every archived source name to its actual file. Readers do not need the authors' earlier ZIP archives.

`results/experiment_index.csv` links all 110 principal records to raw logs and portable configurations. The full 19-class Cityscapes table is in `results/target_19class.csv`.

## Verify and reproduce the analysis

No GPU or third-party packages are needed for the result checks:

```bash
python scripts/verify_results.py
```

To regenerate the quantitative figures:

```bash
python -m pip install numpy matplotlib
python scripts/plot_statistics.py --data . --out generated/quantitative
```

The reported standard deviation is the **population** standard deviation (`ddof=0`), and the stability score is `S = mean(mIoU) - std(mIoU)`. Final-budget validation scores are used for the principal ranking; best-seen scores are not substituted.

Run labels and actual random seeds are different fields. Some historical launch commands did not pass the nominal seed to the trainer. Actual seeds recovered from logs are published explicitly; the five repeats must not be described as a matched-seed comparison across all policies. See [source selection](docs/SOURCE_SELECTION.md).

## Training and evaluation

The CUDA runtime is based on Python 3.10, PyTorch 2.1.2, MMCV 1.7.2, MMSegmentation 0.30.0 and NATTEN 0.17.3. The source includes the pinned SegMAN CUDA kernels and the archived study backbone. See [installation and execution](docs/REPRODUCIBILITY.md) for environment setup, ImageNet initialization, dataset paths, training and evaluation commands.

```bash
python scripts/run_experiment.py --role target160k --policy 6411 --label 0 --dry-run
```

This release has been checked by parsing configurations, verifying archived logs and recomputing numerical analyses. It has **not** been validated by repeating 160k training runs in a new environment.

## Datasets, predictions and checkpoints

Cityscapes and ADE20K must be obtained from their official providers under the applicable terms. Original dataset images and annotation files are not redistributed here. [Dataset access and data availability](DATA_AVAILABILITY.md) explains the distinction between external benchmark data and the experimental evidence deposited here.

The 45 included prediction masks are genuine model outputs. Image IDs, fixed crops, inference settings and checkpoint hashes are included. With a licensed local Cityscapes copy, the figure scripts recreate the comparisons; see [qualitative reproduction](docs/QUALITATIVE.md).

**Trained weights are not bundled and no public checkpoint download URL is currently supplied.** Checkpoint hashes establish provenance, not availability. Some original weights were removed after the predictions and raw results were saved. Repeating checkpoint inference requires a retained matching checkpoint or fresh training. The archived metrics and saved predictions can be inspected independently of those weights.

## Attribution and licenses

SegMAN and MMSegmentation components retain their Apache-2.0 notices. The vendored NVIDIA SegFormer files use the separate NVIDIA Source Code License with a non-commercial research/evaluation restriction. Other inherited notices are retained; see [third-party notices](THIRD_PARTY_NOTICES.md). This repository's license does not replace benchmark dataset terms.

This archive also preserves existing LINKSR diagnostic evidence and implementation switches for the original study. The completed target lattice and its new analyses concern FIXSR; this release does not introduce a new LINKSR architecture or additional datasets.
