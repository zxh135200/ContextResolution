"""Updated quantitative figures; existing Python backend, no GPU work."""
import argparse,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--out',required=True);a=p.parse_args()
data=Path(a.data);out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],'font.size':7,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
stats=json.loads((data/'results'/'target_policy_statistics.json').read_text())['statistics'];ranks=json.loads((data/'results'/'proxy_to_target_analysis.json').read_text());pareto=json.loads((data/'results'/'accuracy_resource_pareto.json').read_text())
def save(fig,name):
 for ext in ['png','pdf','svg']:fig.savefig(out/(name+'.'+ext),dpi=300,bbox_inches='tight')
 plt.close(fig)
fig,axes=plt.subplots(1,3,figsize=(7.2,2.6))
for ax,key,title in zip(axes,['mean','std_population','S'],['Final160k mean mIoU','Population standard deviation','Stability S = mean - std']):
 data=np.array([[stats[str(s1)+str(s2)+'11'][key] for s2 in [2,3,4]] for s1 in [4,6,8]])
 im=ax.imshow(data,cmap='Blues' if key!='std_population' else 'Greys',vmin=0 if key=='std_population' else float(data.min()),vmax=float(data.max()),aspect='equal')
 for i,s1 in enumerate([4,6,8]):
  for j,s2 in enumerate([2,3,4]):
   val=data[i,j];norm=(val-im.norm.vmin)/(im.norm.vmax-im.norm.vmin)
   ax.text(j,i,'%s%s11\n%.3f'%(s1,s2,val),ha='center',va='center',fontsize=6.5,color='white' if norm>.65 else 'black')
 ax.set_xticks([0,1,2],[2,3,4]);ax.set_yticks([0,1,2],[4,6,8]);ax.set_xlabel('Stage2 SR ratio');ax.set_ylabel('Stage1 SR ratio');ax.set_title(title,fontsize=7);fig.colorbar(im,ax=ax,fraction=.047,pad=.035)
fig.tight_layout();save(fig,'target_lattice_statistics')
fig,axes=plt.subplots(1,2,figsize=(7.2,3.2),gridspec_kw={'width_ratios':[1.1,1]});a=ranks['analysis']['S'];ax=axes[0];colors={'6411':'#7659A4','4311':'#167D8D','8211':'#BD7738'}
for r in a['per_policy']:
 c=colors.get(r['policy'],'#9C9C9C');ax.plot([0,1],[r['proxy_rank'],r['target_rank']],color=c,lw=1,alpha=.9 if r['policy'] in colors else .6);ax.text(-.05,r['proxy_rank'],r['policy'],ha='right',va='center',color=c);ax.text(1.05,r['target_rank'],r['policy'],ha='left',va='center',color=c)
ax.set_xlim(-.25,1.25);ax.set_ylim(9.6,.4);ax.set_xticks([0,1],['8k proxy (S)','160k target (S)']);ax.set_yticks(range(1,10));ax.set_ylabel('Observed rank (nine policies)');ax.set_title('Proxy-to-target ranking',fontsize=8)
axes[0].text(.5,-.18,'Spearman rho = %.3f; Kendall tau-b = %.3f'%(a['spearman_rho'],a['kendall_tau_b']),transform=axes[0].transAxes,ha='center',fontsize=6)
for metric,c,label in [('S','#167D8D','Stability S'),('mean','#BD7738','Mean mIoU')]:
 s=ranks['analysis'][metric]['shortlists'];axes[1].plot([x['k'] for x in s],[x['observed_regret_percentage_points'] for x in s],'-o',markersize=3,color=c,label=label)
axes[1].set_xlabel('Proxy shortlist size k');axes[1].set_ylabel('Observed target-score regret (pp)');axes[1].set_xticks(range(1,10));axes[1].set_ylim(bottom=-.015);axes[1].legend(frameon=False,fontsize=6.5);axes[1].set_title('Retrospective shortlist regret',fontsize=8)
fig.tight_layout();save(fig,'proxy_target_ranking_and_regret')
fig,ax=plt.subplots(figsize=(7.2,3.3));points=pareto['points'];front=pareto['frontiers']['lattice_plus_control']['mean_mIoU']['latency_ms_mean'];offset={'1111':(-8,8),'4211':(12,-4),'4311':(7,5),'4411':(-2,9),'6211':(-20,-13),'6311':(-14,-14),'6411':(-8,10),'8211':(-33,12),'8311':(8,5),'8411':(7,-9)}
for p in points:
 c=colors.get(p['policy'],'#34495E' if p['policy']=='1111' else '#777777');sd=stats[p['policy']]['std_population'];ax.errorbar(p['latency_ms_mean'],p['mean_mIoU'],yerr=sd,color=c,alpha=.4,lw=.7,capsize=2);ax.scatter(p['latency_ms_mean'],p['mean_mIoU'],c=c,s=23,zorder=3);ax.annotate(p['policy'],(p['latency_ms_mean'],p['mean_mIoU']),xytext=offset[p['policy']],textcoords='offset points',fontsize=7,color=c)
f=sorted((p for p in points if p['policy'] in front),key=lambda p:p['latency_ms_mean']);ax.plot([p['latency_ms_mean'] for p in f],[p['mean_mIoU'] for p in f],ls='--',color='#777777',lw=.8,label='Observed mean-accuracy frontier (control included)')
ax.set_xlabel('RTX4090 crop encode_decode latency (ms;768x768,batch1,FP32)');ax.set_ylabel('Full-validation final160k mean mIoU (%)');ax.legend(frameon=False,fontsize=6.2,loc='lower right');ax.set_xlim(61,68.1);ax.set_title('Accuracy / latency tradeoff',fontsize=8)
fig.text(.01,-.02,'Whiskers: population standard deviation of five original labelled repeats. Not confidence intervals or paired-seed tests.',fontsize=6);fig.tight_layout();save(fig,'accuracy_latency_pareto')

assert len(list(out.glob('*.pdf')))==3
assert all('<text' in p.read_text() for p in out.glob('*.svg'))
print(json.dumps(dict(complete=True,figures=3,formats=['pdf','png','svg'],SVG_text_editable=True)))
