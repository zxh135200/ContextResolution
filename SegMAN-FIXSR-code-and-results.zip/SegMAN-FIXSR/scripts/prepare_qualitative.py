"""Recreate private figure inputs using an authorized local Cityscapes copy."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--cityscapes-root',required=True,type=Path)
    p.add_argument('--out',required=True,type=Path)
    p.add_argument('--flat-inputs',action='store_true',help='Inputs are directly inside the supplied root.')
    a=p.parse_args();base=a.out.resolve()
    # Generated private inputs must not be written into the publication sources.
    if base==ROOT or base==ROOT/'qualitative' or base==ROOT/'evidence':
        p.error('Use a generated output directory, not a published source directory.')
    base.mkdir(parents=True,exist_ok=True)
    q=ROOT/'qualitative'
    for name in ['selection.json','protocol.json','models.json']:
        shutil.copyfile(q/name,base/name)
    shutil.copytree(q/'configs',base/'configs',dirs_exist_ok=True)
    selection=json.loads((q/'selection.json').read_text())
    protocol=json.loads((q/'protocol.json').read_text())
    pal=np.zeros((256,3),dtype=np.uint8);pal[:19]=protocol['class_palette_rgb']
    for row in selection['images']:
        for key,top in [('image','leftImg8bit'),('labelTrainIds','gtFine')]:
            item=row['files'][key];name=Path(item['path']).name
            source=a.cityscapes_root/name if a.flat_inputs else a.cityscapes_root/top/'val'/row['city']/name
            if not source.is_file():
                p.error('Missing local dataset file: '+str(source))
            if digest(source)!=item['sha256']:
                p.error('Dataset hash mismatch: '+str(source)+'. The archived validation target is required; see docs/QUALITATIVE.md.')
            dest=base/item['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
        gt=np.asarray(Image.open(base/row['files']['labelTrainIds']['path']))
        dest=base/row['ground_truth_color'];dest.parent.mkdir(parents=True,exist_ok=True);Image.fromarray(pal[gt]).save(dest)
        for policy in ['1111','4311','8311']:
            src=q/'predictions'/policy/'trainIds'/(row['id']+'.png')
            mask=np.asarray(Image.open(src));assert mask.shape==(1024,2048) and mask.max()<19
            for kind,arr in [('trainIds',mask),('color',pal[mask])]:
                target=base/'predictions'/policy/kind/src.name;target.parent.mkdir(parents=True,exist_ok=True);Image.fromarray(arr).save(target)
    (base/'inference_complete.json').write_text(json.dumps(dict(complete=True,source='saved authentic predictions',new_inference=False,images=15,policies=['1111','4311','8311']))+'\n')
    print('Prepared 15 licensed input/GT pairs and 45 archived prediction masks at',base)

if __name__=='__main__':
    main()
