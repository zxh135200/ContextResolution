"""Verify deposited raw evidence and reproduce analysis without a GPU."""
import argparse,csv,hashlib,json,math,re,statistics,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--base',default=str(Path(__file__).resolve().parents[1]));args=p.parse_args();base=Path(args.base)
def load(rel):return json.loads((base/rel).read_text(encoding='utf-8'))
def rows(rel):return list(csv.DictReader((base/rel).open(encoding='utf-8-sig',newline='')))
def digest(data):return hashlib.sha256(data).hexdigest()
data=rows('results/target_per_seed.csv');classes=rows('results/target_19class.csv');stats=load('results/target_policy_statistics.json')['statistics'];proxy=load('results/proxy_to_target_analysis.json');pareto=load('results/accuracy_resource_pareto.json')
assert len(data)==len(classes)==50 and len({(r['policy'],r['nominal_seed']) for r in data})==50
actual={}
for policy in stats:
 group=[r for r in data if r['policy']==policy];assert len(group)==5 and len({r['actual_seed'] for r in group})==5
 vals=[float(r['final_mIoU']) for r in group];mu=sum(vals)/5;sd=math.sqrt(sum((v-mu)**2 for v in vals)/5)
 actual[policy]=dict(mean=mu,std_population=sd,S=mu-sd)
 for key,val in actual[policy].items():assert abs(val-stats[policy][key])<1e-10,(policy,key)
class_names=[k for k in classes[0] if k not in data[0]];assert len(class_names)==19
for row in classes:assert abs(sum(float(row[c]) for c in class_names)/19-float(row['final_mIoU']))<.02
cs=load('results/target_19class_policy_statistics.json')['statistics']
for policy in stats:
 for c in class_names:
  vals=[float(r[c]) for r in classes if r['policy']==policy]
  assert abs(statistics.mean(vals)-cs[policy][c]['mean'])<1e-10
  assert abs(statistics.pstdev(vals)-cs[policy][c]['std_population'])<1e-10
ps={}
for policy in proxy['common_policy_set']:
 vals=[r['final_mIoU'] for r in proxy['proxy_raw_records'] if r['policy']==policy];assert len(vals)==5
 ps[policy]=dict(mean=statistics.mean(vals),S=statistics.mean(vals)-statistics.pstdev(vals))
for metric in ['mean','S']:
 keys=sorted(ps);x={p:ps[p][metric] for p in keys};y={p:actual[p][metric] for p in keys};assert len(set(x.values()))==len(set(y.values()))==9
 xo=sorted(keys,key=lambda p:-x[p]);yo=sorted(keys,key=lambda p:-y[p]);xr={p:xo.index(p)+1 for p in keys};yr={p:yo.index(p)+1 for p in keys}
 rho=1-6*sum((xr[p]-yr[p])**2 for p in keys)/(9*(9**2-1));concord=0
 for i,p in enumerate(keys):
  for q in keys[i+1:]:concord+=1 if (x[p]-x[q])*(y[p]-y[q])>0 else -1
 tau=concord/36;ref=proxy['analysis'][metric]
 assert abs(rho-ref['spearman_rho'])<1e-10 and abs(tau-ref['kendall_tau_b'])<1e-10
 assert xo==ref['proxy_order'] and yo==ref['target_order']
 for k,s in enumerate(ref['shortlists'],1):assert abs(max(y.values())-max(y[p] for p in xo[:k])-s['observed_regret_percentage_points'])<1e-10
for scope,ref in pareto['frontiers'].items():
 group=[r for r in pareto['points'] if scope!='lattice_only' or r['role']=='lattice']
 for metric in ref:
  for resource,expected in ref[metric].items():
   cols=['params_M','fvcore_GFLOPs','latency_ms_mean','peak_memory_MB_mean'] if resource=='all_four_resources' else [resource]
   front=[]
   for row in group:
    good=True
    for other in group:
     a=[-row[metric]]+[row[c] for c in cols];b=[-other[metric]]+[other[c] for c in cols]
     if all(v<=u for u,v in zip(a,b)) and any(v<u for u,v in zip(a,b)):good=False
    if good:front.append(row['policy'])
   assert set(front)==set(expected),(scope,metric,resource)

index=rows('results/experiment_index.csv')
assert len(index)==110
assert {role:sum(r['role']==role for r in index) for role in ['target160k','proxy8k','transfer8k','ADE20K160k']}==dict(target160k=50,proxy8k=45,transfer8k=6,ADE20K160k=9)
for r in index:
 raw=(base/r['raw_log']).read_bytes()
 assert digest(raw)==r['source_log_sha256'],r['raw_log']
 text=raw.decode('utf-8',errors='replace').replace('\r','')
 vals=list(re.finditer(r'Iter\(val\)\s*\[\d+\][^\n]*?mIoU:\s*([0-9.]+)[^\n]*',text))
 assert vals and abs(float(vals[-1][1])*100-float(r['final_mIoU']))<1e-7,(r['role'],r['policy'],r['nominal_seed'])
 seeds=re.findall(r'Set random seed to (\d+)',text)
 assert seeds and int(seeds[-1])==int(r['actual_seed']),(r['raw_log'],'actual seed')
 iters=[int(v) for v in re.findall(r'Iter \[([0-9]+)/[0-9]+\]',text)]
 assert iters and max(iters)>=int(r['budget']),(r['raw_log'],'budget')
 assert r['portable_config'] and (base/r['portable_config']).is_file()
 if r['role']=='target160k':
  table=next(v for v in classes if v['policy']==r['policy'] and v['nominal_seed']==r['nominal_seed'])
  cm={k:float(v)*100 for k,v in re.findall(r'(?<![A-Za-z.])IoU\.([^:,]+):\s*([0-9.]+)',vals[-1].group())}
  assert all(abs(float(table[c])-cm[c])<1e-7 for c in class_names)
source_index=load('provenance/raw_source_index.json')
for r in source_index:
 assert digest((base/r['file']).read_bytes())==r['sha256'],r['file']
ef=next(r for r in source_index if r['original_member'].endswith('/03_efficiency_10policy/results/efficiency_10policy_summary.csv'))
resource=list(csv.DictReader((base/ef['file']).open(encoding='utf-8-sig',newline='')))
for point in pareto['points']:
 row=next(r for r in resource if r['policy']==point['policy'])
 for key in ['params_M','fvcore_GFLOPs','latency_ms_mean','peak_memory_MB_mean']:
  assert abs(float(row[key])-point[key])<1e-9,(point['policy'],key)
for row in proxy['proxy_raw_records']:
 record=next(r for r in index if r['role']=='proxy8k' and r['policy']==row['policy'] and int(r['nominal_seed'])==row['nominal_seed'])
 assert record['source_log_sha256']==row['source_log_sha256'] and abs(float(record['final_mIoU'])-row['final_mIoU'])<1e-9
selection=load('qualitative/selection.json')
assert len(selection['images'])==15 and selection['frozen_before_predictions']
assert sum(len(list((base/'qualitative/predictions'/p/'trainIds').glob('*.png'))) for p in ['1111','4311','8311'])==45
assert abs(actual['4211']['mean']-80.626)<1e-10
manifest=base/'MANIFEST.json'
if manifest.is_file():
 for row in json.loads(manifest.read_text(encoding='utf-8')):
  assert digest((base/row['file']).read_bytes())==row['sha256'],row['file']
print(json.dumps(dict(verified=True,raw_principal_experiments=110,target=50,proxy=45,SegFormer=6,ADE20K=9,per_class_statistics=True,rank_correlations_and_shortlist_regret=True,Pareto_frontiers=True,raw_resource_table=True,qualitative_masks=45,actual_seeds_checked=True,raw_aliases_verified=len(source_index))))
