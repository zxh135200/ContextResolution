# Adapted for the public study release; inputs are prepared from licensed local benchmark files.
"""Traceable image plates from genuine masks, with identical annotation-fixed crops."""
import argparse,hashlib,json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Patch
import numpy as np
from PIL import Image
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],'font.size':7,'svg.fonttype':'none','pdf.fonttype':42})
parser=argparse.ArgumentParser();parser.add_argument('--base',required=True);parser.add_argument('--output-dir');args=parser.parse_args();base=Path(args.base)
selection=json.loads((base/'selection.json').read_text());protocol=json.loads((base/'protocol.json').read_text());assert json.loads((base/'inference_complete.json').read_text())['complete']
out=Path(args.output_dir) if args.output_dir else base/'figures';out.mkdir(parents=True,exist_ok=True)
contract=dict(core_conclusion='Show the actual segmentation behavior of three trained spatial-reduction policies on identical, annotation-selected validation scenes; these illustrative cases cannot establish a policy ranking.',evidence_chain='Original RGB and the validation-target GT anchor the three real-checkpoint predictions; the same GT-fixed zoom is applied to all five columns.',archetype='image plate + quant; quantitative benchmark results supplied separately',backend='Python matplotlib',dimensions_inches=[7.2,2.3],outputs=['PNG300dpi','PDF with editable text','SVG with editable text'],integrity='Original RGB and masks preserved byte-for-byte; Cityscapes class palette only; no brightness/contrast/gamma edits. Crops and annotation boxes are declared. TrainId GT follows the original validation target; labelId-derived differences are retained. Three different policies have one available checkpoint each, with seed0/0/2; no paired-seed inference.',roi_source='selection.json frozen before predictions')
(out/'figure_contract.json').write_text(json.dumps(contract,indent=2)+'\n')
def sources(row):
 return [base/row['files']['image']['path'],base/row['ground_truth_color']]+[base/'predictions'/policy/'color'/(row['id']+'.png') for policy in ['1111','4311','8311']]
titles=['Original image','Ground truth','1111 (seed0)','4311 (seed0)','8311 (seed2)']
for i,row in enumerate(selection['images'],1):
 fig=plt.figure(figsize=(7.2,2.3));axes=np.empty((2,5),dtype=object);panel_w=(7.2-.04-4*.025)/5;zoom_h=panel_w*.75;full_h=panel_w*.5
 for k in range(5):
  x=(.02+k*(panel_w+.025))/7.2
  axes[0,k]=fig.add_axes([x,(.17+zoom_h+.045)/2.3,panel_w/7.2,full_h/2.3])
  axes[1,k]=fig.add_axes([x,.17/2.3,panel_w/7.2,zoom_h/2.3])
 left,top,right,bottom=row['roi_xyxy']
 for k,(path,title) in enumerate(zip(sources(row),titles)):
  arr=np.asarray(Image.open(path));assert arr.shape==(1024,2048,3)
  for ax,img in [(axes[0,k],arr),(axes[1,k],arr[top:bottom,left:right])]:ax.imshow(img,interpolation='nearest');ax.axis('off')
  axes[0,k].set_title(title,fontsize=7,pad=4);axes[0,k].add_patch(Rectangle((left,top),right-left,bottom-top,fill=False,edgecolor='white',linewidth=.6,linestyle='--'))
 fig.suptitle(chr(96+i)+'. '+row['theme'].replace('_',' ')+' | '+row['id'],fontsize=7.3,y=.98)
 fig.text(.01,.01,'Top: full frame. Bottom: identical GT-selected 512x384 crop. Ignore pixels: black. Illustrative single-checkpoint comparison.',fontsize=5.5)
 name=out/('%02d_%s'%(i,row['id']))
 for ext in ['png','pdf','svg']:fig.savefig(str(name)+'.'+ext,dpi=300)
 plt.close(fig)
 print('FIGURE_EXPORTED',row['id'],flush=True)
fig,axes=plt.subplots(5,3,figsize=(10.8,10.8))
for ax,row in zip(axes.ravel(),selection['images']):
 ax.imshow(Image.open(base/row['files']['image']['path']));ax.axis('off');ax.set_title(row['theme'].replace('_',' ')+'\n'+row['id'],fontsize=7)
fig.tight_layout();fig.savefig(out/'all_15_fixed_scenes.png',dpi=150);plt.close(fig)
fig,ax=plt.subplots(figsize=(7.2,1.5));ax.axis('off');handles=[Patch(facecolor=np.array(color)/255,label=name) for name,color in zip(protocol['protocol']['classes'],protocol['class_palette_rgb'])];handles.append(Patch(facecolor='black',label='ignore / unlabeled'))
ax.legend(handles=handles,ncol=5,loc='center',frameon=False,fontsize=6.5,columnspacing=1,handlelength=1.2)
for ext in ['png','pdf','svg']:fig.savefig(out/('cityscapes_palette.'+ext),dpi=300,bbox_inches='tight')
plt.close(fig)
legend='Qualitative Cityscapes validation comparisons. Fifteen scenes were frozen before model inference, using GT-polygon scores for small objects, thin structures, crowded scenes, distant objects and contextual complexity; one case per theme per validation city. Each sheet shows the original image, the GT labelTrainIds used by the original validation pipeline, and real 160k-checkpoint predictions from1111 seed0,4311 seed0 and8311 seed2. The lower row applies the identical annotation-selected512x384 crop to all columns. Predictions use FP32, single-scale2048x1024 preprocessing, no test-time flipping, and768x768 sliding windows with stride256. Colors follow the Cityscapes19-class palette; ignored GT pixels are black.1111 and4311 are supplementary runs to restore missing reference weights;8311 is an available original run. These selected examples are illustrative, do not replace full-validation metrics and do not establish a paired-seed or isolated policy effect. Raw RGB, both original GT encodings, masks, selection rules, crop coordinates, configs, checkpoint hashes and execution receipts are retained. Small differences between provided trainId GT and canonical labelId conversion are recorded per image; the shared validation target is used consistently.'
(out/'figure_legend_EN.txt').write_text(legend+'\n')
(out/'image_integrity.json').write_text(json.dumps(dict(raw_files_preserved=True,contrast_adjustments='none',palette='Cityscapes19-class',interpolation_for_masks='nearest',crop_coordinates_source='selection.json',sample_selection_consulted_predictions=False,canonical_GT_mapping_differences={r['id']:r['label_mapping_audit'] for r in selection['images']}),indent=2)+'\n')
assert len(list(out.glob('[0-9][0-9]_*.png')))==15
(out/'render_complete.json').write_text(json.dumps(dict(complete=True,scene_sheets=15,formats=['png','pdf','svg'],contact_sheet='all_15_fixed_scenes.png',legend='cityscapes_palette.png'),indent=2)+'\n')
