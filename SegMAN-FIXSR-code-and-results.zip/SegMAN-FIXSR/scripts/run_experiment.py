"""Select a recorded experiment and pass its actual seed to MMSegmentation."""
import argparse
import csv
import os
from pathlib import Path
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--role', required=True, choices=['target160k', 'proxy8k', 'transfer8k', 'ADE20K160k'])
    p.add_argument('--policy', required=True)
    p.add_argument('--label', type=int, required=True)
    p.add_argument('--gpu', default='0')
    p.add_argument('--work-dir')
    p.add_argument('--dry-run', action='store_true')
    a = p.parse_args()
    with (ROOT/'results/experiment_index.csv').open(encoding='utf-8', newline='') as f:
        matches=[r for r in csv.DictReader(f) if r['role']==a.role and r['policy']==a.policy and int(r['nominal_seed'])==a.label]
    if len(matches)!=1:
        p.error('No unique experiment matches this role/policy/label.')
    r=matches[0]
    if not r['portable_config']:
        p.error('A portable config is not available for this record.')
    output=Path(a.work_dir).resolve() if a.work_dir else ROOT/'work_dirs'/a.role/(a.policy+'_label'+str(a.label))
    cmd=[sys.executable, 'tools/train.py', str(ROOT/r['portable_config']), '--work-dir', str(output), '--seed', r['actual_seed']]
    print('Nominal label:',a.label,'; recorded actual seed:',r['actual_seed'],flush=True)
    rendered=subprocess.list2cmdline(cmd) if os.name=='nt' else shlex.join(cmd)
    print('CUDA_VISIBLE_DEVICES='+a.gpu, rendered, flush=True)
    if a.dry_run:
        return
    if not os.environ.get('SEG_DATA_ROOT') or not Path(os.environ['SEG_DATA_ROOT']).is_dir():
        p.error('Set SEG_DATA_ROOT to an existing dataset root. See docs/REPRODUCIBILITY.md.')
    env=dict(os.environ, CUDA_VISIBLE_DEVICES=a.gpu)
    raise SystemExit(subprocess.call(cmd,cwd=ROOT/'segmentation',env=env))

if __name__=='__main__':
    main()
