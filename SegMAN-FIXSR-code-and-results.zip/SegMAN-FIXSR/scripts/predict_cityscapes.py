# Adapted for the public study release; original checkpoint hashes and strict loading retained.
"""Real checkpoint inference on a frozen, shared Cityscapes image list."""
import argparse,datetime,gc,hashlib,json,os,sys,time
from pathlib import Path
P=Path(__file__).resolve().parents[1]/'segmentation';sys.path.insert(0,str(P))
import mmcv,numpy as np,torch
from PIL import Image
from mmseg.apis import init_segmentor,inference_segmentor

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
 return h.hexdigest()
def atomic(p,data):
 p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name(p.name+'.partial');t.write_text(json.dumps(data,indent=2)+'\n');os.replace(t,p)
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--base',required=True);parser.add_argument('--checkpoint-dir',required=True);parser.add_argument('--policies',nargs='+',default=['1111','4311','8311']);args=parser.parse_args()
 base=Path(args.base).resolve();models=json.loads((base/'models.json').read_text());selection=json.loads((base/'selection.json').read_text());protocol=json.loads((base/'protocol.json').read_text())
 palette=np.zeros((256,3),dtype=np.uint8);palette[:19]=protocol['class_palette_rgb'];label_ids=np.asarray(protocol['trainId_to_labelId'],dtype=np.uint8)
 torch.set_num_threads(2);torch.backends.cudnn.benchmark=False;torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
 for policy in args.policies:
  out=base/'predictions'/policy;out.mkdir(parents=True,exist_ok=True);m=models[policy];cp=Path(args.checkpoint_dir).resolve()/(policy+'.pth');expected=m['checkpoint_sha256']
  assert cp.is_file() and sha(cp)==expected,('Checkpoint checksum mismatch',policy,str(cp))
  cfg=mmcv.Config.fromfile(str(base/'configs'/Path(m['config']).name))
  assert list(cfg.model.backbone.sr_ratios)==list(map(int,policy))
  actual=dict(test_pipeline=cfg.data.test.pipeline,test_cfg=cfg.model.test_cfg,classes=protocol['protocol']['classes'])
  assert json.loads(json.dumps(actual))==protocol['protocol']
  cfg.model.pretrained=None;cfg.model.backbone.pretrained=None;cfg.model.train_cfg=None
  model=init_segmentor(cfg,checkpoint=None,device='cuda:0',CLASSES=protocol['protocol']['classes'],PALETTE=protocol['class_palette_rgb'])
  checkpoint=torch.load(str(cp),map_location='cpu');state=checkpoint.get('state_dict',checkpoint)
  if all(k.startswith('module.') for k in state):state={k[7:]:v for k,v in state.items()}
  incompatible=model.load_state_dict(state,strict=True);assert not incompatible.missing_keys and not incompatible.unexpected_keys
  meta=checkpoint.get('meta',{});meta_seed=meta.get('seed');assert meta_seed is None or int(meta_seed)==m['seed'],('Seed mismatch',meta_seed,m['seed'])
  model.eval();del checkpoint,state;gc.collect();torch.cuda.empty_cache()
  conf=np.zeros((19,19),dtype=np.int64);per_image=[];started=time.time();torch.cuda.reset_peak_memory_stats()
  atomic(base/'runtime_status.json',dict(phase='inference',policy=policy,completed_images=0,total_images=selection['number']))
  for index,row in enumerate(selection['images'],1):
   stem=row['id'];image=base/row['files']['image']['path'];assert sha(image)==row['files']['image']['sha256'];gtpath=base/row['files']['labelTrainIds']['path'];assert sha(gtpath)==row['files']['labelTrainIds']['sha256']
   torch.cuda.synchronize();t=time.perf_counter()
   with torch.no_grad():pred=np.asarray(inference_segmentor(model,str(image))[0],dtype=np.uint8)
   torch.cuda.synchronize();seconds=time.perf_counter()-t
   gt=np.asarray(Image.open(gtpath));assert pred.shape==gt.shape==(1024,2048) and int(pred.max())<19
   valid=gt!=255;c=np.bincount((gt[valid].astype(np.int64)*19+pred[valid]).ravel(),minlength=361).reshape(19,19);conf+=c
   names={}
   for kind,array in [('trainIds',pred),('labelIds',label_ids[pred]),('color',palette[pred])]:
    target=out/kind/(stem+'.png');target.parent.mkdir(exist_ok=True);Image.fromarray(array).save(target);names[kind]=dict(path=str(target.relative_to(base)),sha256=sha(target))
   union=c.sum(0)+c.sum(1)-np.diag(c);ious=np.divide(np.diag(c),union,out=np.full(19,np.nan),where=union>0)
   detail=dict(image_id=stem,theme=row['theme'],seconds=seconds,files=names,pixel_accuracy=float(np.diag(c).sum()/c.sum()),mean_IoU_present_classes_percent=float(np.nanmean(ious)*100),class_IoU_percent={n:None if not np.isfinite(v) else float(v*100) for n,v in zip(protocol['protocol']['classes'],ious)})
   per_image.append(detail);atomic(out/'per_image.json',per_image);atomic(base/'runtime_status.json',dict(phase='inference',policy=policy,completed_images=index,total_images=selection['number'],last_image=stem))
   print(datetime.datetime.now().astimezone().isoformat(),'PREDICTED',policy,index,stem,round(seconds,3),flush=True)
  union=conf.sum(0)+conf.sum(1)-np.diag(conf);ious=np.divide(np.diag(conf),union,out=np.full(19,np.nan),where=union>0)
  np.save(out/'subset_confusion_matrix.npy',conf)
  receipt=dict(complete=True,policy=policy,seed=m['seed'],training_iterations=160000,original_checkpoint_sha256=m['checkpoint_sha256'],inference_checkpoint_sha256=expected,checkpoint_meta_seed=meta_seed,strict_state_dict_load=True,selection_sha256=sha(base/'selection.json'),protocol_sha256=sha(base/'protocol.json'),config_sha256=sha(base/'configs'/Path(m['config']).name),number_images=len(per_image),inference_only_seconds=time.time()-started,gpu=dict(name=torch.cuda.get_device_name(0),torch_peak_allocated_MiB=torch.cuda.max_memory_allocated()/1024**2),runtime=dict(torch=torch.__version__,cuda=torch.version.cuda,mmcv=mmcv.__version__,python=sys.version),precision='FP32; autocast disabled; TF32 disabled',subset_mIoU_percent=float(np.nanmean(ious)*100),subset_class_IoU_percent={n:None if not np.isfinite(v) else float(v*100) for n,v in zip(protocol['protocol']['classes'],ious)},subset_metrics_caution='15 GT-selected examples; illustrative only, not the full500-image benchmark and not a paired seed comparison.',files=per_image,completed_at=datetime.datetime.now().astimezone().isoformat())
  atomic(out/'complete.json',receipt);del model;gc.collect();torch.cuda.empty_cache()
 atomic(base/'inference_complete.json',dict(complete=True,policies=args.policies,images_per_policy=selection['number'],selection_sha256=sha(base/'selection.json'),completed_at=datetime.datetime.now().astimezone().isoformat()))
 atomic(base/'runtime_status.json',dict(phase='complete',policies=args.policies,images_per_policy=selection['number']))
 print('ALL_REAL_CHECKPOINT_PREDICTIONS_COMPLETE',flush=True)
if __name__=='__main__':main()
