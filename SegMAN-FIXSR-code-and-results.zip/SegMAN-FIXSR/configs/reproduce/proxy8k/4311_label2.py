# Portable effective settings recovered from the immutable raw log.
# Recorded actual seed is used; label is an archival identifier.
# See docs/REPRODUCIBILITY.md for path and infrastructure adaptations.
norm_cfg = {'type': 'BN', 'requires_grad': True}
model = {'type': 'EncoderDecoder',
 'pretrained': '/data/ZhangXinHui/code/SegMAN/segmentation/pretrained/SegMAN_Encoder_b_state_dict_ema.pth',
 'backbone': {'type': 'SegMANEncoder_b',
              'style': 'pytorch',
              'pretrained': None,
              'sr_ratios': [4, 3, 1, 1],
              'linksr_coupling': False,
              'linksr_v2_coupling': False,
              'linksr_v2_detach_context': False},
 'decode_head': {'type': 'SegMANDecoder',
                 'in_channels': [96, 160, 364, 560],
                 'in_index': [0, 1, 2, 3],
                 'channels': 180,
                 'dropout_ratio': 0.1,
                 'num_classes': 19,
                 'norm_cfg': {'type': 'GN', 'num_groups': 30, 'requires_grad': True},
                 'align_corners': False,
                 'decoder_params': {'embed_dim': 128},
                 'loss_decode': {'type': 'CrossEntropyLoss',
                                 'use_sigmoid': False,
                                 'loss_weight': 1.0},
                 'feat_proj_dim': 320},
 'train_cfg': {},
 'test_cfg': {'mode': 'slide', 'crop_size': (768, 768), 'stride': (256, 256)}}
dataset_type = 'CityscapesDataset'
data_root = 'data/cityscapes/'
img_norm_cfg = {'mean': [123.675, 116.28, 103.53], 'std': [58.395, 57.12, 57.375], 'to_rgb': True}
crop_size = (768, 768)
train_pipeline = [{'type': 'LoadImageFromFile'},
 {'type': 'LoadAnnotations'},
 {'type': 'Resize', 'img_scale': (2048, 1024), 'ratio_range': (0.5, 2.0)},
 {'type': 'RandomCrop', 'crop_size': (768, 768), 'cat_max_ratio': 0.75},
 {'type': 'RandomFlip', 'prob': 0.5},
 {'type': 'PhotoMetricDistortion'},
 {'type': 'Normalize',
  'mean': [123.675, 116.28, 103.53],
  'std': [58.395, 57.12, 57.375],
  'to_rgb': True},
 {'type': 'Pad', 'size': (1024, 1024), 'pad_val': 0, 'seg_pad_val': 255},
 {'type': 'DefaultFormatBundle'},
 {'type': 'Collect', 'keys': ['img', 'gt_semantic_seg']}]
test_pipeline = [{'type': 'LoadImageFromFile'},
 {'type': 'MultiScaleFlipAug',
  'img_scale': (2048, 1024),
  'flip': False,
  'transforms': [{'type': 'Resize', 'keep_ratio': True},
                 {'type': 'RandomFlip'},
                 {'type': 'Normalize',
                  'mean': [123.675, 116.28, 103.53],
                  'std': [58.395, 57.12, 57.375],
                  'to_rgb': True},
                 {'type': 'ImageToTensor', 'keys': ['img']},
                 {'type': 'Collect', 'keys': ['img']}]}]
data = {'samples_per_gpu': 1,
 'workers_per_gpu': 0,
 'train': {'type': 'RepeatDataset',
           'times': 500,
           'dataset': {'type': 'CityscapesDataset',
                       'data_root': 'data/cityscapes/',
                       'img_dir': 'leftImg8bit/train',
                       'ann_dir': 'gtFine/train',
                       'pipeline': [{'type': 'LoadImageFromFile'},
                                    {'type': 'LoadAnnotations'},
                                    {'type': 'Resize',
                                     'img_scale': (2048, 1024),
                                     'ratio_range': (0.5, 2.0)},
                                    {'type': 'RandomCrop',
                                     'crop_size': (768, 768),
                                     'cat_max_ratio': 0.75},
                                    {'type': 'RandomFlip', 'prob': 0.5},
                                    {'type': 'PhotoMetricDistortion'},
                                    {'type': 'Normalize',
                                     'mean': [123.675, 116.28, 103.53],
                                     'std': [58.395, 57.12, 57.375],
                                     'to_rgb': True},
                                    {'type': 'Pad',
                                     'size': (1024, 1024),
                                     'pad_val': 0,
                                     'seg_pad_val': 255},
                                    {'type': 'DefaultFormatBundle'},
                                    {'type': 'Collect', 'keys': ['img', 'gt_semantic_seg']}]}},
 'val': {'type': 'CityscapesDataset',
         'data_root': 'data/cityscapes/',
         'img_dir': 'leftImg8bit/val',
         'ann_dir': 'gtFine/val',
         'pipeline': [{'type': 'LoadImageFromFile'},
                      {'type': 'MultiScaleFlipAug',
                       'img_scale': (2048, 1024),
                       'flip': False,
                       'transforms': [{'type': 'Resize', 'keep_ratio': True},
                                      {'type': 'RandomFlip'},
                                      {'type': 'Normalize',
                                       'mean': [123.675, 116.28, 103.53],
                                       'std': [58.395, 57.12, 57.375],
                                       'to_rgb': True},
                                      {'type': 'ImageToTensor', 'keys': ['img']},
                                      {'type': 'Collect', 'keys': ['img']}]}]},
 'test': {'type': 'CityscapesDataset',
          'data_root': 'data/cityscapes/',
          'img_dir': 'leftImg8bit/val',
          'ann_dir': 'gtFine/val',
          'pipeline': [{'type': 'LoadImageFromFile'},
                       {'type': 'MultiScaleFlipAug',
                        'img_scale': (2048, 1024),
                        'flip': False,
                        'transforms': [{'type': 'Resize', 'keep_ratio': True},
                                       {'type': 'RandomFlip'},
                                       {'type': 'Normalize',
                                        'mean': [123.675, 116.28, 103.53],
                                        'std': [58.395, 57.12, 57.375],
                                        'to_rgb': True},
                                       {'type': 'ImageToTensor', 'keys': ['img']},
                                       {'type': 'Collect', 'keys': ['img']}]}]},
 'persistent_workers': False,
 'train_dataloader': {'workers_per_gpu': 0, 'persistent_workers': False},
 'val_dataloader': {'workers_per_gpu': 0, 'persistent_workers': False},
 'test_dataloader': {'workers_per_gpu': 0, 'persistent_workers': False}}
log_config = {'interval': 50, 'hooks': [{'type': 'TextLoggerHook', 'by_epoch': False}]}
dist_params = {'backend': 'nccl'}
log_level = 'INFO'
workflow = [('train', 1)]
cudnn_benchmark = True
optimizer = {'type': 'AdamW',
 'lr': 6e-05,
 'betas': (0.9, 0.999),
 'weight_decay': 0.01,
 'paramwise_cfg': {'custom_keys': {'pos_block': {'decay_mult': 0.0},
                                   'norm': {'decay_mult': 0.0},
                                   'head': {'lr_mult': 10.0}}}}
optimizer_config = {}
lr_config = {'policy': 'poly',
 'warmup': 'linear',
 'warmup_iters': 1500,
 'warmup_ratio': 1e-06,
 'power': 1.0,
 'min_lr': 0.0,
 'by_epoch': False}
runner = {'type': 'IterBasedRunner', 'max_iters': 8000}
checkpoint_config = {'by_epoch': False, 'interval': 8000, 'max_keep_ckpts': 1, 'save_last': True}
evaluation = {'interval': 4000, 'metric': 'mIoU', 'pre_eval': True}
find_unused_parameters = False
max_iters = 8000
total_iters = 8000
seed = 309826436
randomness = {'seed': 309826436, 'deterministic': False}
gpu_ids = [0]
load_from = None
resume_from = None
auto_resume = False

import os
# Override only local file locations.
if model.get('pretrained'):
    model['pretrained'] = os.environ.get('SEGMAN_PRETRAINED' if 'SegMAN' in model['pretrained'] else 'TRANSFER_PRETRAINED', 'pretrained/' + os.path.basename(model['pretrained']))
if model.get('backbone', {}).get('pretrained'):
    model['backbone']['pretrained'] = os.environ.get('TRANSFER_PRETRAINED', 'pretrained/' + os.path.basename(model['backbone']['pretrained']))
data_root = os.environ.get('SEG_DATA_ROOT', 'data/ade20k/' if 'ADE20K' in dataset_type else 'data/cityscapes/')
def _set_root(item):
    if isinstance(item, dict):
        if 'data_root' in item:
            item['data_root'] = data_root
        for val in item.values():
            _set_root(val)
    elif isinstance(item, (list, tuple)):
        for val in item:
            _set_root(val)
_set_root(data)
del _set_root
