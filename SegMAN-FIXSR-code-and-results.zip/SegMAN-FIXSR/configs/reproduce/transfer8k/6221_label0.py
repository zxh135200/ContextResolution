# Portable effective settings recovered from the immutable raw log.
# Recorded actual seed is used; label is an archival identifier.
# See docs/REPRODUCIBILITY.md for path and infrastructure adaptations.
dataset_type = 'CityscapesDataset'
data_root = 'data/cityscapes/'
img_norm_cfg = {'mean': [123.675, 116.28, 103.53], 'std': [58.395, 57.12, 57.375], 'to_rgb': True}
crop_size = (768, 768)
train_pipeline = [{'type': 'LoadImageFromFile'},
 {'type': 'LoadAnnotations'},
 {'type': 'Resize', 'img_scale': (2048, 1024), 'ratio_range': (0.5, 2.0)},
 {'type': 'RandomCrop', 'crop_size': (768, 768), 'cat_max_ratio': 0.75},
 {'type': 'RandomFlip', 'prob': 0.5},
 {'type': 'PhotoMetricDistortion'},
 {'type': 'Normalize',
  'mean': [123.675, 116.28, 103.53],
  'std': [58.395, 57.12, 57.375],
  'to_rgb': True},
 {'type': 'Pad', 'size': (768, 768), 'pad_val': 0, 'seg_pad_val': 255},
 {'type': 'DefaultFormatBundle'},
 {'type': 'Collect', 'keys': ['img', 'gt_semantic_seg']}]
test_pipeline = [{'type': 'LoadImageFromFile'},
 {'type': 'MultiScaleFlipAug',
  'img_scale': (2048, 1024),
  'flip': False,
  'transforms': [{'type': 'Resize', 'keep_ratio': True},
                 {'type': 'RandomFlip'},
                 {'type': 'Normalize',
                  'mean': [123.675, 116.28, 103.53],
                  'std': [58.395, 57.12, 57.375],
                  'to_rgb': True},
                 {'type': 'ImageToTensor', 'keys': ['img']},
                 {'type': 'Collect', 'keys': ['img']}]}]
data = {'samples_per_gpu': 2,
 'workers_per_gpu': 2,
 'train': {'type': 'RepeatDataset',
           'times': 500,
           'dataset': {'type': 'CityscapesDataset',
                       'data_root': 'data/cityscapes/',
                       'img_dir': 'leftImg8bit/train',
                       'ann_dir': 'gtFine/train',
                       'pipeline': [{'type': 'LoadImageFromFile'},
                                    {'type': 'LoadAnnotations'},
                                    {'type': 'Resize',
                                     'img_scale': (2048, 1024),
                                     'ratio_range': (0.5, 2.0)},
                                    {'type': 'RandomCrop',
                                     'crop_size': (768, 768),
                                     'cat_max_ratio': 0.75},
                                    {'type': 'RandomFlip', 'prob': 0.5},
                                    {'type': 'PhotoMetricDistortion'},
                                    {'type': 'Normalize',
                                     'mean': [123.675, 116.28, 103.53],
                                     'std': [58.395, 57.12, 57.375],
                                     'to_rgb': True},
                                    {'type': 'Pad',
                                     'size': (768, 768),
                                     'pad_val': 0,
                                     'seg_pad_val': 255},
                                    {'type': 'DefaultFormatBundle'},
                                    {'type': 'Collect', 'keys': ['img', 'gt_semantic_seg']}]}},
 'val': {'type': 'CityscapesDataset',
         'data_root': 'data/cityscapes/',
         'img_dir': 'leftImg8bit/val',
         'ann_dir': 'gtFine/val',
         'pipeline': [{'type': 'LoadImageFromFile'},
                      {'type': 'MultiScaleFlipAug',
                       'img_scale': (2048, 1024),
                       'flip': False,
                       'transforms': [{'type': 'Resize', 'keep_ratio': True},
                                      {'type': 'RandomFlip'},
                                      {'type': 'Normalize',
                                       'mean': [123.675, 116.28, 103.53],
                                       'std': [58.395, 57.12, 57.375],
                                       'to_rgb': True},
                                      {'type': 'ImageToTensor', 'keys': ['img']},
                                      {'type': 'Collect', 'keys': ['img']}]}]},
 'test': {'type': 'CityscapesDataset',
          'data_root': 'data/cityscapes/',
          'img_dir': 'leftImg8bit/val',
          'ann_dir': 'gtFine/val',
          'pipeline': [{'type': 'LoadImageFromFile'},
                       {'type': 'MultiScaleFlipAug',
                        'img_scale': (2048, 1024),
                        'flip': False,
                        'transforms': [{'type': 'Resize', 'keep_ratio': True},
                                       {'type': 'RandomFlip'},
                                       {'type': 'Normalize',
                                        'mean': [123.675, 116.28, 103.53],
                                        'std': [58.395, 57.12, 57.375],
                                        'to_rgb': True},
                                       {'type': 'ImageToTensor', 'keys': ['img']},
                                       {'type': 'Collect', 'keys': ['img']}]}]}}
log_config = {'interval': 50, 'hooks': [{'type': 'TextLoggerHook', 'by_epoch': False}]}
dist_params = {'backend': 'nccl'}
log_level = 'INFO'
workflow = [('train', 1)]
cudnn_benchmark = True
optimizer = {'type': 'AdamW',
 'lr': 6e-05,
 'weight_decay': 0.01,
 'betas': (0.9, 0.999),
 'paramwise_cfg': {'custom_keys': {'pos_block': {'decay_mult': 0.0},
                                   'norm': {'decay_mult': 0.0},
                                   'head': {'lr_mult': 10.0}}}}
optimizer_config = {}
lr_config = {'policy': 'poly',
 'power': 1.0,
 'min_lr': 0.0,
 'by_epoch': False,
 'warmup': 'linear',
 'warmup_iters': 1500,
 'warmup_ratio': 1e-06}
runner = {'type': 'IterBasedRunner', 'max_iters': 8000}
checkpoint_config = {'by_epoch': False, 'interval': 1000, 'save_last': True, 'max_keep_ckpts': 2}
evaluation = {'interval': 1000, 'metric': 'mIoU', 'pre_eval': True}
norm_cfg = {'type': 'SyncBN', 'requires_grad': True}
model = {'type': 'EncoderDecoder',
 'pretrained': None,
 'backbone': {'type': 'MixVisionTransformer',
              'in_channels': 3,
              'embed_dims': 32,
              'num_stages': 4,
              'num_layers': [2, 2, 2, 2],
              'num_heads': [1, 2, 5, 8],
              'patch_sizes': [7, 3, 3, 3],
              'sr_ratios': [6, 2, 2, 1],
              'out_indices': (0, 1, 2, 3),
              'mlp_ratio': 4,
              'qkv_bias': True,
              'drop_rate': 0.0,
              'attn_drop_rate': 0.0,
              'drop_path_rate': 0.1},
 'decode_head': {'type': 'SegformerHead',
                 'in_channels': [32, 64, 160, 256],
                 'feature_strides': [4, 8, 16, 32],
                 'in_index': [0, 1, 2, 3],
                 'channels': 256,
                 'decoder_params': {'embed_dim': 256},
                 'dropout_ratio': 0.1,
                 'num_classes': 19,
                 'norm_cfg': {'type': 'SyncBN', 'requires_grad': True},
                 'align_corners': False,
                 'loss_decode': {'type': 'CrossEntropyLoss',
                                 'use_sigmoid': False,
                                 'loss_weight': 1.0}},
 'train_cfg': {},
 'test_cfg': {'mode': 'whole'}}
find_unused_parameters = False
seed = 1738697437
randomness = {'seed': 1738697437, 'deterministic': False}
gpu_ids = [0]
load_from = None
resume_from = None
auto_resume = False

import os
# Override only local file locations.
if model.get('pretrained'):
    model['pretrained'] = os.environ.get('SEGMAN_PRETRAINED' if 'SegMAN' in model['pretrained'] else 'TRANSFER_PRETRAINED', 'pretrained/' + os.path.basename(model['pretrained']))
if model.get('backbone', {}).get('pretrained'):
    model['backbone']['pretrained'] = os.environ.get('TRANSFER_PRETRAINED', 'pretrained/' + os.path.basename(model['backbone']['pretrained']))
data_root = os.environ.get('SEG_DATA_ROOT', 'data/ade20k/' if 'ADE20K' in dataset_type else 'data/cityscapes/')
def _set_root(item):
    if isinstance(item, dict):
        if 'data_root' in item:
            item['data_root'] = data_root
        for val in item.values():
            _set_root(val)
    elif isinstance(item, (list, tuple)):
        for val in item:
            _set_root(val)
_set_root(data)
del _set_root
