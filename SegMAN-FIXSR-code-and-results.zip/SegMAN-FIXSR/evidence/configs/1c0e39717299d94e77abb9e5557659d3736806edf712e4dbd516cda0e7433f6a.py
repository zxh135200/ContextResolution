_base_ = './W42_OFFICIAL_FIXSR_srRatio4211_seed0_160k.py'

model = dict(
    backbone=dict(
        sr_ratios=[6, 4, 1, 1]
    )
)

randomness = dict(seed=1)

work_dir = '/6411_full160k/work_dirs/seed1'


custom_imports = dict(
    imports=['mmseg.core.hook.gpu_collision_guard'],
    allow_failed_imports=False
)

custom_hooks = [
    dict(
        type='PersistentCacheFloorHook',
        interval=4000,
        floor_mb=12288,
        chunk_mb=128,
        safety_free_mb=3072,
        priority='BELOW_NORMAL'
    )
]
