import csv
import time
import argparse
import traceback
from pathlib import Path

import torch
from mmcv import Config
from mmseg.models import build_segmentor


def build_model(cfg_path):
    cfg = Config.fromfile(cfg_path)
    model_cfg = cfg.model.copy()

    train_cfg = None if "train_cfg" in model_cfg else cfg.get("train_cfg", None)
    test_cfg = None if "test_cfg" in model_cfg else cfg.get("test_cfg", None)

    model = build_segmentor(model_cfg, train_cfg=train_cfg, test_cfg=test_cfg)
    model.eval()
    return model


def count_params(model):
    return sum(p.numel() for p in model.parameters())


def measure_once(model, h, w, warmup, repeat):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device).eval()

    x = torch.randn(1, 3, h, w, device=device)
    img_metas = [dict(
        ori_shape=(h, w, 3),
        img_shape=(h, w, 3),
        pad_shape=(h, w, 3),
        scale_factor=1.0,
        flip=False,
    )]

    if device.type == "cuda":
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats(device)

    with torch.no_grad():
        for _ in range(warmup):
            _ = model.encode_decode(x, img_metas)

        if device.type == "cuda":
            torch.cuda.synchronize()

        t0 = time.time()
        for _ in range(repeat):
            _ = model.encode_decode(x, img_metas)

        if device.type == "cuda":
            torch.cuda.synchronize()

        t1 = time.time()

    latency_ms = (t1 - t0) * 1000.0 / repeat
    fps = 1000.0 / latency_ms

    if device.type == "cuda":
        memory_mb = torch.cuda.max_memory_allocated(device) / 1024 / 1024
    else:
        memory_mb = 0.0

    return latency_ms, fps, memory_mb


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--height", type=int, default=768)
    parser.add_argument("--width", type=int, default=768)
    parser.add_argument("--warmup", type=int, default=50)
    parser.add_argument("--repeat", type=int, default=200)
    parser.add_argument("--trials", type=int, default=3)
    args = parser.parse_args()

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    row = {
        "name": args.name,
        "config": args.config,
        "input": f"{args.height}x{args.width}",
        "params_M": "",
        "latency_ms_mean": "",
        "latency_ms_trials": "",
        "fps_mean": "",
        "fps_trials": "",
        "memory_MB_mean": "",
        "memory_MB_trials": "",
        "status": "ok",
        "error": "",
    }

    try:
        model = build_model(args.config)
        row["params_M"] = f"{count_params(model) / 1e6:.3f}"

        latencies, fps_list, mems = [], [], []
        for _ in range(args.trials):
            latency, fps, mem = measure_once(
                model, args.height, args.width, args.warmup, args.repeat
            )
            latencies.append(latency)
            fps_list.append(fps)
            mems.append(mem)

        row["latency_ms_mean"] = f"{sum(latencies) / len(latencies):.3f}"
        row["latency_ms_trials"] = "/".join(f"{x:.3f}" for x in latencies)
        row["fps_mean"] = f"{sum(fps_list) / len(fps_list):.3f}"
        row["fps_trials"] = "/".join(f"{x:.3f}" for x in fps_list)
        row["memory_MB_mean"] = f"{sum(mems) / len(mems):.1f}"
        row["memory_MB_trials"] = "/".join(f"{x:.1f}" for x in mems)

    except Exception:
        row["status"] = "failed"
        row["error"] = traceback.format_exc()

    write_header = not out.exists()
    with out.open("a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        if write_header:
            writer.writeheader()
        writer.writerow(row)

    print(row)


if __name__ == "__main__":
    main()
