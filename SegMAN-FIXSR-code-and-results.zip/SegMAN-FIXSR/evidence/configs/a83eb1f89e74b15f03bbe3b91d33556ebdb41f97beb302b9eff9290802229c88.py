_base_ = ['./W36_NW0_PRETRAIN_6211_FIXSR_seed0_8k.py']

seed = 0
randomness = dict(seed=0, deterministic=False)

model = dict(
    backbone=dict(
        sr_ratios=[8, 3, 1, 1],
        linksr_coupling=False,
        linksr_v2_coupling=False,
        linksr_v2_detach_context=False,
    )
)

work_dir = (
    '/data/tmp/ZhangXinHui/segman_outputs/work_dirs/'
    'W40_OFFICIAL_FIXSR_srRatio8311_seed0_8k'
)
exp_name = 'W40_OFFICIAL_FIXSR_srRatio8311_seed0_8k'

runner = dict(
    type='IterBasedRunner',
    max_iters=8000,
)

checkpoint_config = dict(
    by_epoch=False,
    interval=8000,
    save_last=True,
    max_keep_ckpts=1,
)

resume_from = None
