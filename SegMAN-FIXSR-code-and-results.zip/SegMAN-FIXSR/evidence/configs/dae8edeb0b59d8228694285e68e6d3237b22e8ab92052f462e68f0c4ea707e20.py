from pathlib import Path
import csv
import numpy as np
import matplotlib.pyplot as plt

BASE = Path("/data/tmp/ZhangXinHui/segman_outputs")
MECH = BASE / "KEEP_RECORDS" / "mechanism_w36_training_curves"
TABLE = MECH / "tables"
CURVES = MECH / "curves"
CURVES.mkdir(parents=True, exist_ok=True)

methods = ["8411_FIXSR", "6211_FIXSR", "6211_LINKSR"]

# val mIoU mean/std curve
rows = []
with (TABLE / "w36_val_miou_mean_std.csv").open() as f:
    reader = csv.DictReader(f)
    for r in reader:
        rows.append(r)

plt.figure(figsize=(7, 5))
for method in methods:
    sub = [r for r in rows if r["method"] == method and int(r["n"]) >= 1]
    sub.sort(key=lambda r: int(r["eval_index"]))
    if not sub:
        continue
    x = np.array([int(r["eval_index"]) for r in sub])
    y = np.array([float(r["mIoU_mean"]) for r in sub])
    e = np.array([float(r["mIoU_std_ddof0"]) for r in sub])
    plt.plot(x, y, marker="o", label=method)
    plt.fill_between(x, y - e, y + e, alpha=0.15)

plt.xlabel("Validation index")
plt.ylabel("mIoU")
plt.title("Cityscapes full160k validation mIoU")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(CURVES / "w36_val_miou_mean_std.png", dpi=300)
plt.close()

# train loss raw curve, downsample by plotting all available points per seed lightly
train = []
with (TABLE / "w36_train_loss_raw.csv").open() as f:
    reader = csv.DictReader(f)
    for r in reader:
        if r["loss"] != "":
            train.append(r)

plt.figure(figsize=(7, 5))
for method in methods:
    sub = [r for r in train if r["method"] == method]
    sub.sort(key=lambda r: int(r["iter"]))
    if not sub:
        continue
    # mean by iter across seeds
    by_iter = {}
    for r in sub:
        by_iter.setdefault(int(r["iter"]), []).append(float(r["loss"]))
    xs, ys = [], []
    for it in sorted(by_iter):
        xs.append(it)
        ys.append(float(np.mean(by_iter[it])))
    # downsample for readability
    step = max(1, len(xs) // 500)
    plt.plot(xs[::step], ys[::step], label=method)

plt.xlabel("Iteration")
plt.ylabel("Training loss")
plt.title("Cityscapes full160k training loss")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(CURVES / "w36_train_loss_mean.png", dpi=300)
plt.close()

print("[WRITE]", CURVES / "w36_val_miou_mean_std.png")
print("[WRITE]", CURVES / "w36_train_loss_mean.png")
