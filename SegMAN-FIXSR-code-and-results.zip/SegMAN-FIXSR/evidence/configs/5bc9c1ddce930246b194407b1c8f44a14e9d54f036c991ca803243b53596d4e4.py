_base_ = ['./W36_NW0_PRETRAIN_8411_FIXSR_seed0_160k.py']

seed = 3
randomness = dict(seed=3, deterministic=False)

model = dict(
    backbone=dict(
        sr_ratios=[8, 4, 1, 1],
        linksr_coupling=False,
        linksr_v2_coupling=False,
        linksr_v2_detach_context=False,
    )
)

runner = dict(
    type='IterBasedRunner',
    max_iters=160000,
)

checkpoint_config = dict(
    by_epoch=False,
    interval=160000,
    save_last=True,
    max_keep_ckpts=1,
)

work_dir = (
    '/data/tmp/ZhangXinHui/segman_outputs/work_dirs/'
    'W47_CITYSCAPES_5SEED_8411_FIXSR_seed3_160k'
)
exp_name = 'W47_CITYSCAPES_5SEED_8411_FIXSR_seed3_160k'

resume_from = None
