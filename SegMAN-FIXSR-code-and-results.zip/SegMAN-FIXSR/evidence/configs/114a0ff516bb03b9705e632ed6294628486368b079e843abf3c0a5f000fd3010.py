_base_ = ['./W36_NW0_PRETRAIN_6211_FIXSR_seed0_160k.py']

seed = 0
randomness = dict(seed=0, deterministic=False)

model = dict(
    backbone=dict(
        sr_ratios=[4, 3, 1, 1],
        linksr_coupling=False,
        linksr_v2_coupling=False,
        linksr_v2_detach_context=False,
    )
)

work_dir = (
    '/data/tmp/ZhangXinHui/segman_outputs/work_dirs/'
    'W42_OFFICIAL_FIXSR_srRatio4311_seed0_160k'
)
exp_name = 'W42_OFFICIAL_FIXSR_srRatio4311_seed0_160k'

runner = dict(
    type='IterBasedRunner',
    max_iters=160000,
)

checkpoint_config = dict(
    by_epoch=False,
    interval=40000,
    save_last=True,
    max_keep_ckpts=1,
)

evaluation = dict(
    interval=4000,
    metric='mIoU',
    pre_eval=True,
)

resume_from = None
