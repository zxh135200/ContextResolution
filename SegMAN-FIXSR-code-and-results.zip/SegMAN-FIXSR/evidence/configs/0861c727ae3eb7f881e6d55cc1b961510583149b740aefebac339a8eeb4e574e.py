_base_ = ['./W45_ADE20K_STD160K_6211_FIXSR_seed0.py']

seed = 0
randomness = dict(seed=0, deterministic=False)

model = dict(
    backbone=dict(
        sr_ratios=[4, 3, 1, 1],
        linksr_coupling=False,
        linksr_v2_coupling=False,
        linksr_v2_detach_context=False,
    )
)

runner = dict(
    type='IterBasedRunner',
    max_iters=160000,
)

checkpoint_config = dict(
    by_epoch=False,
    interval=160000,
    save_last=True,
    max_keep_ckpts=1,
)

resume_from = None

work_dir = (
    '/data/tmp/ZhangXinHui/segman_outputs/work_dirs/'
    'W48_ADE20K_STD160K_4311_FIXSR_seed0'
)

exp_name = 'W48_ADE20K_STD160K_4311_FIXSR_seed0'
