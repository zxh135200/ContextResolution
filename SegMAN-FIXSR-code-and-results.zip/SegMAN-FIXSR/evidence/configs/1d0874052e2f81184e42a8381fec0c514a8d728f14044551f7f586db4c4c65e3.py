_base_ = ['./W37_STAGE3SENS_srRatio6211_LINKSR_seed0_8k.py']

seed = 1
randomness = dict(seed=1, deterministic=False)

model = dict(
    backbone=dict(
        linksr_coupling=False,
        linksr_v2_coupling=True,
        linksr_v2_detach_context=False,
    )
)

work_dir = (
    '/data/tmp/ZhangXinHui/segman_outputs/work_dirs/'
    'W39_LINKSRPAIR_srRatio6211_V2_seed1_8k'
)
exp_name = 'W39_LINKSRPAIR_srRatio6211_V2_seed1_8k'

resume_from = None
