_base_ = './W41_OFFICIAL_FIXSR_srRatio8311_seed1_8k.py'

seed = 3
randomness = dict(seed=3, deterministic=False)

work_dir = '/data/tmp/ZhangXinHui/kbs_revision_20260923/proxy_8k_seed34/work_dirs/8311_seed3'
resume_from = None
