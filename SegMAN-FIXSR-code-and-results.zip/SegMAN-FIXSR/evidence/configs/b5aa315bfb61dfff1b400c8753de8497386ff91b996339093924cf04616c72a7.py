_base_ = ['./W37_STAGE3SENS_srRatio6211_LINKSR_seed0_8k.py']

model = dict(
    backbone=dict(
        linksr_coupling=True,
        linksr_alpha_init=0.0,
        linksr_v2_coupling=False,
    )
)

work_dir = (
    '/data/tmp/ZhangXinHui/segman_outputs/work_dirs/'
    'W38_LINKSRABL_srRatio6211_V1INPUT_seed0_8k'
)
exp_name = 'W38_LINKSRABL_srRatio6211_V1INPUT_seed0_8k'
