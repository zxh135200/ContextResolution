_base_ = './W42_OFFICIAL_FIXSR_srRatio4211_seed0_160k.py'

seed = 4
randomness = dict(seed=4)

work_dir = '/data/tmp/ZhangXinHui/kbs_revision_20260923/4211_full160k_seed34/work_dirs/seed4'
resume_from = None
