_base_ = ['./W37_ADE20K_PRETRAIN_8411_FIXSR_seed0_20k.py']

seed = 0
randomness = dict(seed=0, deterministic=False)

model = dict(
    backbone=dict(
        sr_ratios=[8, 4, 1, 1],
        linksr_coupling=False,
        linksr_v2_coupling=False,
        linksr_v2_detach_context=False,
    )
)

runner = dict(
    type='IterBasedRunner',
    max_iters=160000,
)

evaluation = dict(
    interval=8000,
    metric='mIoU',
    pre_eval=True,
)

checkpoint_config = dict(
    by_epoch=False,
    interval=40000,
    save_last=True,
    max_keep_ckpts=1,
)

work_dir = (
    '/data/tmp/ZhangXinHui/segman_outputs/work_dirs/'
    'W45_ADE20K_STD160K_8411_FIXSR_seed0'
)
exp_name = 'W45_ADE20K_STD160K_8411_FIXSR_seed0'

resume_from = None
