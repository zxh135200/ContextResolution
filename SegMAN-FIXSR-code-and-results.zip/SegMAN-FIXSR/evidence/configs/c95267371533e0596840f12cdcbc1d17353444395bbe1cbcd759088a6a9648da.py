_base_ = './W42_OFFICIAL_FIXSR_srRatio4211_seed0_160k.py'

model = dict(
    backbone=dict(
        sr_ratios=[8, 3, 1, 1]
    )
)

randomness = dict(seed=2)

work_dir = '/data/tmp/ZhangXinHui/pr_revision_20261005/8311_full160k/work_dirs/seed2'


custom_imports = dict(
    imports=['mmseg.core.hook.gpu_collision_guard'],
    allow_failed_imports=False
)

custom_hooks = [
    dict(
        type='ValidationVRAMFencePreHook',
        interval=4000,
        floor_mb=12288,
        hold_mb=9216,
        chunk_mb=256,
        priority='BELOW_NORMAL'
    ),
    dict(
        type='ValidationVRAMFencePostHook',
        interval=4000,
        priority='LOWEST'
    )
]

# ==== PR_CACHE_QUEUE_20261010_V1 ====

# Replace the old live-tensor VRAM fence.
# Freed temporary blocks remain reusable by this
# process through PyTorch's CUDA caching allocator.

custom_hooks = [
    dict(
        type='PersistentCacheFloorHook',
        interval=4000,
        floor_mb=12288,
        chunk_mb=128,
        safety_free_mb=3072,
        priority='BELOW_NORMAL'
    )
]

# Keep resumable checkpoints.
checkpoint_config = dict(
    by_epoch=False,
    interval=4000,
    max_keep_ckpts=2,
    save_last=True
)

# PR_QUEUE_V2: future launch only; do not affect active seed1/seed3.
__import__('runpy').run_path('/data/tmp/ZhangXinHui/pr_revision_20261005/_protected_launch/v2/launch_gate.py')
custom_hooks = [dict(type='ValidationVRAMFencePreHook', interval=4000, floor_mb=12288, hold_mb=9216, chunk_mb=256, priority='BELOW_NORMAL'), dict(type='ValidationVRAMFencePostHook', interval=4000, priority='LOWEST')]
checkpoint_config = dict(by_epoch=False, interval=4000, max_keep_ckpts=2, save_last=True)
