_base_ = ['./W42_OFFICIAL_FIXSR_srRatio4311_seed0_160k.py']

seed = 1
randomness = dict(seed=1, deterministic=False)

work_dir = (
    '/data/tmp/ZhangXinHui/segman_outputs/work_dirs/'
    'W43_OFFICIAL_FIXSR_srRatio4311_seed1_160k'
)
exp_name = 'W43_OFFICIAL_FIXSR_srRatio4311_seed1_160k'

resume_from = None
