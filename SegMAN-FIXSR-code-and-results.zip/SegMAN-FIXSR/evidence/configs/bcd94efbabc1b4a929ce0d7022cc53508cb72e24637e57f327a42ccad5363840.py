_base_ = ['./W37_STAGE3SENS_srRatio6211_LINKSR_seed0_8k.py']

model = dict(
    backbone=dict(
        linksr_coupling=False,
        linksr_v2_coupling=True,
        linksr_v2_detach_context=True,
    )
)

work_dir = (
    '/data/tmp/ZhangXinHui/segman_outputs/work_dirs/'
    'W38_LINKSRABL_srRatio6211_V2DETACH_seed0_8k'
)
exp_name = 'W38_LINKSRABL_srRatio6211_V2DETACH_seed0_8k'
