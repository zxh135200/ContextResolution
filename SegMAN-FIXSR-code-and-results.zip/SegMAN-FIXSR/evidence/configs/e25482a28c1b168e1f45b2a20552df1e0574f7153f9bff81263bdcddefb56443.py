_base_ = ['./W42_OFFICIAL_FIXSR_srRatio4211_seed0_160k.py']

seed = 2
randomness = dict(seed=2, deterministic=False)

work_dir = (
    '/data/tmp/ZhangXinHui/segman_outputs/work_dirs/'
    'W44_OFFICIAL_FIXSR_srRatio4211_seed2_160k'
)
exp_name = 'W44_OFFICIAL_FIXSR_srRatio4211_seed2_160k'

resume_from = None
