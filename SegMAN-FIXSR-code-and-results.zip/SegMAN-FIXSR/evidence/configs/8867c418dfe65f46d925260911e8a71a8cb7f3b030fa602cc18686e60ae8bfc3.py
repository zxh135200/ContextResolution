_base_ = [r'./segman_b_cityscapes_stage1_coarse_V1stableBN_crop768.py']

seed = 0
gpu_ids = [0]
work_dir = r'/data/tmp/ZhangXinHui/segman_outputs/work_dirs/W23_FIXSR_srRatio6211_train768_seed0_8k'
exp_name = 'W23_FIXSR_srRatio6211_train768_seed0_8k'

model = dict(
    backbone=dict(
        sr_ratios=[6, 2, 1, 1]
    )
)

runner = dict(type='IterBasedRunner', max_iters=8000)
checkpoint_config = dict(by_epoch=False, interval=8000, max_keep_ckpts=1)
evaluation = dict(interval=8000, metric='mIoU')

model['test_cfg'] = dict(mode='slide', crop_size=(768, 768), stride=(256, 256))

# W23_FIXSR no checkpoint saving, keep meta for tools/train.py
checkpoint_config = dict(interval=999999999, by_epoch=False, meta=dict())


# ===== W25 current-code FIXSR paired control =====
seed = 0
gpu_ids = [0]

work_dir = r'/data/tmp/ZhangXinHui/segman_outputs/work_dirs/W25_CTRL_FIXSR_srRatio6211_train768_seed0_8k'
exp_name = r'W25_CTRL_FIXSR_srRatio6211_train768_seed0_8k'

model = dict(
    backbone=dict(
        sr_ratios=[6, 2, 1, 1],
        linksr_coupling=False,
        linksr_v2_coupling=False,
    )
)

runner = dict(type='IterBasedRunner', max_iters=8000)
checkpoint_config = dict(by_epoch=False, interval=8000, max_keep_ckpts=1)
evaluation = dict(interval=8000, metric='mIoU')


# ===== W35 current-code FIXSR 9-policy seed0 8k for 18-candidate joint search =====
seed = 0
gpu_ids = [0]

work_dir = r'/data/tmp/ZhangXinHui/segman_outputs/work_dirs/W35_CTRL_FIXSR_srRatio8411_train768_seed0_8k'
exp_name = r'W35_CTRL_FIXSR_srRatio8411_train768_seed0_8k'

load_from = None
resume_from = None

model = dict(
    backbone=dict(
        sr_ratios=[8, 4, 1, 1],
        linksr_coupling=False,
        linksr_v2_coupling=False,
    )
)

runner = dict(type='IterBasedRunner', max_iters=8000)
checkpoint_config = dict(by_epoch=False, interval=999999999, max_keep_ckpts=1)
evaluation = dict(interval=8000, metric='mIoU')


# ===== W36 FIXSR 8411 stability completion =====
seed = 1
gpu_ids = [0]

work_dir = r'/data/tmp/ZhangXinHui/segman_outputs/work_dirs/W36_CTRL_FIXSR_srRatio8411_train768_seed1_8k'
exp_name = r'W36_CTRL_FIXSR_srRatio8411_train768_seed1_8k'

load_from = None
resume_from = None

model = dict(
    backbone=dict(
        sr_ratios=[8, 4, 1, 1],
        linksr_coupling=False,
        linksr_v2_coupling=False,
    )
)

runner = dict(type='IterBasedRunner', max_iters=8000)
checkpoint_config = dict(by_epoch=False, interval=999999999, max_keep_ckpts=1)
evaluation = dict(interval=8000, metric='mIoU')
