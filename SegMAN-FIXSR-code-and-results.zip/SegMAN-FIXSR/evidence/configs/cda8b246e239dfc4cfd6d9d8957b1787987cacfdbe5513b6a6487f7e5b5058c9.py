_base_ = ['./W45_ADE20K_STD160K_8411_FIXSR_seed0.py']

seed = 2
randomness = dict(seed=2, deterministic=False)

work_dir = (
    '/data/tmp/ZhangXinHui/segman_outputs/work_dirs/'
    'W46_ADE20K_STD160K_8411_FIXSR_seed2'
)
exp_name = 'W46_ADE20K_STD160K_8411_FIXSR_seed2'

resume_from = None
