import re
import csv
import json
from pathlib import Path
import numpy as np

BASE = Path("/data/tmp/ZhangXinHui/segman_outputs")
MECH = BASE / "KEEP_RECORDS" / "mechanism_w36_training_curves"
LOGDIR = MECH / "logs"
OUT = MECH / "tables"
OUT.mkdir(parents=True, exist_ok=True)

logs = {
    ("8411_FIXSR", 0): LOGDIR / "W36_NW0_PRETRAIN_8411_FIXSR_seed0_160k.log",
    ("8411_FIXSR", 1): LOGDIR / "W36_NW0_PRETRAIN_8411_FIXSR_seed1_160k.log",
    ("8411_FIXSR", 2): LOGDIR / "W36_NW0_PRETRAIN_8411_FIXSR_seed2_160k.log",

    ("6211_FIXSR", 0): LOGDIR / "W36_NW0_PRETRAIN_6211_FIXSR_seed0_160k.log",
    ("6211_FIXSR", 1): LOGDIR / "W36_NW0_PRETRAIN_6211_FIXSR_seed1_160k.log",
    ("6211_FIXSR", 2): LOGDIR / "W36_NW0_PRETRAIN_6211_FIXSR_seed2_160k.log",

    ("6211_LINKSR", 0): LOGDIR / "W36_NW0_PRETRAIN_6211_LINKSR_seed0_160k.log",
    ("6211_LINKSR", 1): LOGDIR / "W36_NW0_PRETRAIN_6211_LINKSR_seed1_160k.log",
    ("6211_LINKSR", 2): LOGDIR / "W36_NW0_PRETRAIN_6211_LINKSR_seed2_160k.log",
}

train_rows = []
val_rows = []

def parse_float_after(key, line):
    m = re.search(rf"\b{key}\b\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)", line)
    return float(m.group(1)) if m else None

for (method, seed), path in logs.items():
    if not path.exists():
        print("[MISSING]", path)
        continue

    eval_count = 0
    last_train_iter = None
    last_ckpt_iter = None

    for line in path.read_text(errors="ignore").splitlines():
        # train iter line
        m_iter = re.search(r"Iter\s*\[\s*(\d+)\s*/\s*(\d+)\]", line)
        if m_iter:
            it = int(m_iter.group(1))
            last_train_iter = it

            loss = parse_float_after("loss", line)
            loss_decode = parse_float_after("decode.loss", line)
            lr = parse_float_after("lr", line)

            if loss is not None or loss_decode is not None:
                train_rows.append({
                    "method": method,
                    "seed": seed,
                    "iter": it,
                    "loss": "" if loss is None else loss,
                    "decode_loss": "" if loss_decode is None else loss_decode,
                    "lr": "" if lr is None else lr,
                })

        m_ckpt = re.search(r"Saving checkpoint at\s+(\d+)\s+iterations", line)
        if m_ckpt:
            last_ckpt_iter = int(m_ckpt.group(1))

        # validation metric line
        if "mIoU" in line and ("Iter(val)" in line or "Summary" not in line):
            miou = parse_float_after("mIoU", line)
            macc = parse_float_after("mAcc", line)
            aacc = parse_float_after("aAcc", line)

            if miou is not None:
                if miou <= 1:
                    miou *= 100
                if macc is not None and macc <= 1:
                    macc *= 100
                if aacc is not None and aacc <= 1:
                    aacc *= 100

                eval_count += 1
                # 优先用 checkpoint iter；否则用 eval_count*4000 近似，因为 full160k 通常 interval=4000
                val_iter = last_ckpt_iter if last_ckpt_iter is not None else eval_count * 4000

                val_rows.append({
                    "method": method,
                    "seed": seed,
                    "eval_index": eval_count,
                    "iter": val_iter,
                    "mIoU": miou,
                    "mAcc": "" if macc is None else macc,
                    "aAcc": "" if aacc is None else aacc,
                })

# write raw csv
with (OUT / "w36_train_loss_raw.csv").open("w", newline="") as f:
    fieldnames = ["method", "seed", "iter", "loss", "decode_loss", "lr"]
    w = csv.DictWriter(f, fieldnames=fieldnames)
    w.writeheader()
    w.writerows(train_rows)

with (OUT / "w36_val_miou_raw.csv").open("w", newline="") as f:
    fieldnames = ["method", "seed", "eval_index", "iter", "mIoU", "mAcc", "aAcc"]
    w = csv.DictWriter(f, fieldnames=fieldnames)
    w.writeheader()
    w.writerows(val_rows)

# summarize val by method/eval_index
groups = {}
for r in val_rows:
    key = (r["method"], r["eval_index"], r["iter"])
    groups.setdefault(key, []).append(float(r["mIoU"]))

summary_rows = []
for (method, eval_index, it), vals in sorted(groups.items(), key=lambda x: (x[0][0], x[0][1])):
    arr = np.array(vals, dtype=float)
    summary_rows.append({
        "method": method,
        "eval_index": eval_index,
        "iter": it,
        "n": len(vals),
        "mIoU_mean": f"{arr.mean():.4f}",
        "mIoU_std_ddof0": f"{arr.std(ddof=0):.4f}",
        "mIoU_values": "/".join(f"{v:.4f}" for v in vals),
    })

with (OUT / "w36_val_miou_mean_std.csv").open("w", newline="") as f:
    fieldnames = ["method", "eval_index", "iter", "n", "mIoU_mean", "mIoU_std_ddof0", "mIoU_values"]
    w = csv.DictWriter(f, fieldnames=fieldnames)
    w.writeheader()
    w.writerows(summary_rows)

print("[OK] train rows:", len(train_rows))
print("[OK] val rows:", len(val_rows))
print("[WRITE]", OUT / "w36_train_loss_raw.csv")
print("[WRITE]", OUT / "w36_val_miou_raw.csv")
print("[WRITE]", OUT / "w36_val_miou_mean_std.csv")
