_base_ = '/data/ZhangXinHui/code/SegMAN/segmentation/configs/PR_6411_FIXSR_seed1_160k.py'
work_dir = '/data/tmp/ZhangXinHui/pr_revision_20261005/6411_full160k/work_dirs/seed1'
custom_hooks = [dict(type='ValidationVRAMFencePreHook', interval=4000, floor_mb=12288, hold_mb=9216, chunk_mb=256, priority='BELOW_NORMAL'), dict(type='ValidationVRAMFencePostHook', interval=4000, priority='LOWEST')]
checkpoint_config = dict(by_epoch=False, interval=4000, max_keep_ckpts=2, save_last=True)
