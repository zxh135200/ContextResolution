
_base_ = [
    r'/data/ZhangXinHui/code/SegMAN/segmentation/local_configs/_base_/datasets/cityscapes_768x768_repeat.py',
    r'/data/ZhangXinHui/code/SegMAN/segmentation/local_configs/_base_/default_runtime.py',
    r'/data/ZhangXinHui/code/SegMAN/segmentation/local_configs/_base_/schedules/schedule_160k_adamw.py',
]

norm_cfg = dict(type='SyncBN', requires_grad=True)

model = dict(
    type='EncoderDecoder',
    pretrained=None,
    backbone=dict(
        type='MixVisionTransformer',
        in_channels=3,
        embed_dims=32,
        num_stages=4,
        num_layers=[2, 2, 2, 2],
        num_heads=[1, 2, 5, 8],
        patch_sizes=[7, 3, 3, 3],
        sr_ratios=[8, 4, 2, 1],
        out_indices=(0, 1, 2, 3),
        mlp_ratio=4,
        qkv_bias=True,
        drop_rate=0.0,
        attn_drop_rate=0.0,
        drop_path_rate=0.1,
        
    ),
    decode_head=dict(
        type='SegformerHead',
        in_channels=[32, 64, 160, 256],
        feature_strides=[4, 8, 16, 32],
        in_index=[0, 1, 2, 3],
        channels=256,
        decoder_params=dict(embed_dim=256),
        dropout_ratio=0.1,
        num_classes=19,
        norm_cfg=norm_cfg,
        align_corners=False,
        loss_decode=dict(type='CrossEntropyLoss', use_sigmoid=False, loss_weight=1.0),
    ),
    train_cfg=dict(),
    test_cfg=dict(mode='whole'),
)

# SegFormer-B0 standard optimizer
optimizer = dict(
    type='AdamW',
    lr=0.00006,
    betas=(0.9, 0.999),
    weight_decay=0.01,
    paramwise_cfg=dict(
        custom_keys=dict(
            pos_block=dict(decay_mult=0.),
            norm=dict(decay_mult=0.),
            head=dict(lr_mult=10.),
        )
    )
)
optimizer_config = dict()
lr_config = dict(
    policy='poly',
    warmup='linear',
    warmup_iters=1500,
    warmup_ratio=1e-6,
    power=1.0,
    min_lr=0.0,
    by_epoch=False,
)

seed = 1
gpu_ids = range(1)
work_dir = r'/data/tmp/ZhangXinHui/segman_outputs/work_dirs/segformer_b0_default_8421_seed1_8k'

runner = dict(type='IterBasedRunner', max_iters=8000)
checkpoint_config = dict(by_epoch=False, interval=1000, save_last=True, max_keep_ckpts=2)
evaluation = dict(interval=1000, metric='mIoU', pre_eval=True)
log_config = dict(interval=50, hooks=[dict(type='TextLoggerHook', by_epoch=False)])

randomness = dict(seed=1, deterministic=False)
