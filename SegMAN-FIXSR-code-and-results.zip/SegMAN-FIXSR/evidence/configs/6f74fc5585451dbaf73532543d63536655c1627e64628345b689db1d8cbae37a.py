import csv
from pathlib import Path

ROOT = Path("/data/tmp/ZhangXinHui/kbs_revision_20260923/efficiency_10policy")

runtime_file = ROOT / "runtime_10policy_raw.csv"
flops_file = ROOT / "flops_10policy_raw.csv"
out_file = ROOT / "efficiency_10policy_summary.csv"
protocol_file = ROOT / "EFFICIENCY_PROTOCOL.txt"

with runtime_file.open() as f:
    runtime_rows = list(csv.DictReader(f))

with flops_file.open() as f:
    flops_rows = list(csv.DictReader(f))

runtime = {}
for r in runtime_rows:
    policy = r["name"].replace("_FIXSR", "")
    runtime[policy] = r

flops = {r["policy"]: r for r in flops_rows}

expected = [
    "1111", "4211", "4311", "4411", "6211",
    "6311", "6411", "8211", "8311", "8411"
]

rows = []

for p in expected:
    if p not in runtime:
        raise RuntimeError(f"Missing runtime row: {p}")
    if p not in flops:
        raise RuntimeError(f"Missing FLOPs row: {p}")

    r = runtime[p]
    f = flops[p]

    if r["status"] != "ok":
        raise RuntimeError(f"Runtime failed for {p}")
    if f["status"] != "ok":
        raise RuntimeError(f"FLOPs failed for {p}")

    if r["input"] != f["input"]:
        raise RuntimeError(
            f"Input mismatch {p}: {r['input']} vs {f['input']}"
        )

    runtime_params = float(r["params_M"])
    flops_params = float(f["fvcore_params_M"])

    if abs(runtime_params - flops_params) > 0.002:
        raise RuntimeError(
            f"Params mismatch {p}: "
            f"{runtime_params} vs {flops_params}"
        )

    rows.append({
        "policy": p,
        "input": r["input"],
        "batch_size": 1,
        "params_M": f"{runtime_params:.3f}",
        "fvcore_GFLOPs": f"{float(f['fvcore_GFLOPs']):.3f}",
        "latency_ms_mean": r["latency_ms_mean"],
        "latency_ms_trials": r["latency_ms_trials"],
        "fps_mean": r["fps_mean"],
        "fps_trials": r["fps_trials"],
        "peak_memory_MB_mean": r["memory_MB_mean"],
        "peak_memory_MB_trials": r["memory_MB_trials"],
        "runtime_config": r["config"],
        "flops_config": f["config"],
        "runtime_status": r["status"],
        "flops_status": f["status"],
        "status": "ok",
    })

with out_file.open("w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

protocol_file.write_text(
"""KBS 10-policy unified efficiency protocol

Policies:
1111, 4211, 4311, 4411, 6211, 6311, 6411, 8211, 8311, 8411

Runtime protocol:
- Same NVIDIA GeForce RTX 4090
- Input resolution: 768 x 768
- Batch size: 1
- Precision: FP32
- Model mode: eval
- Inference path: model.encode_decode
- No checkpoint required for architecture profiling
- Random input tensor: [1, 3, 768, 768]
- Warm-up: 50 iterations
- Timed inference: 200 iterations
- Trials: 3
- CUDA synchronization before/after timed region
- Latency: mean wall-clock milliseconds per image
- FPS: 1000 / latency_ms
- Peak GPU memory: torch.cuda.max_memory_allocated

Complexity protocol:
- Same input resolution: 768 x 768
- Batch size: 1
- fvcore counting
- Custom handlers are enabled for SegMAN Selective Scan and NATTEN operations.
- The reported column is named fvcore_GFLOPs.
- Unsupported pointwise, nonlinear, rearrangement and interpolation
  operators reported by fvcore are excluded consistently across policies.
- Raw FLOPs logs are retained for audit.
- Do not reinterpret fvcore_GFLOPs as MACs without a separate MAC-counting convention.

All 10 policies were profiled under the same protocol.
""")

print(f"Wrote: {out_file}")
print(f"Wrote: {protocol_file}")

print()
print("policy params_M GFLOPs latency_ms FPS peak_mem_MB")
for r in rows:
    print(
        f"{r['policy']:>4} "
        f"{r['params_M']:>8} "
        f"{r['fvcore_GFLOPs']:>8} "
        f"{r['latency_ms_mean']:>10} "
        f"{r['fps_mean']:>8} "
        f"{r['peak_memory_MB_mean']:>11}"
    )
