_base_ = './W41_OFFICIAL_FIXSR_srRatio6311_seed1_8k.py'

seed = 4
randomness = dict(seed=4, deterministic=False)

work_dir = '/data/tmp/ZhangXinHui/kbs_revision_20260923/proxy_8k_seed34/work_dirs/6311_seed4'
resume_from = None
