#!/usr/bin/env python3
import csv
import re
from pathlib import Path
from statistics import mean, pstdev

ROOT = Path(
    "/data/tmp/ZhangXinHui/segman_outputs/"
    "KEEP_RECORDS/KBS_FINAL_FREEZE_20260720/logs"
)

POLICIES = [
    "4211", "4311", "4411",
    "6211", "6311", "6411",
    "8211", "8311", "8411",
]

# seed0中，6211和8411来自已冻结的W36_NW0_PRETRAIN；
# 其余七个策略来自W40_OFFICIAL_FIXSR。
SEED0_FILES = {
    "4211": "W40_OFFICIAL_FIXSR_srRatio4211_seed0_8k.log",
    "4311": "W40_OFFICIAL_FIXSR_srRatio4311_seed0_8k.log",
    "4411": "W40_OFFICIAL_FIXSR_srRatio4411_seed0_8k.log",
    "6211": "W36_NW0_PRETRAIN_6211_FIXSR_seed0_8k.log",
    "6311": "W40_OFFICIAL_FIXSR_srRatio6311_seed0_8k.log",
    "6411": "W40_OFFICIAL_FIXSR_srRatio6411_seed0_8k.log",
    "8211": "W40_OFFICIAL_FIXSR_srRatio8211_seed0_8k.log",
    "8311": "W40_OFFICIAL_FIXSR_srRatio8311_seed0_8k.log",
    "8411": "W36_NW0_PRETRAIN_8411_FIXSR_seed0_8k.log",
}


def build_path(policy: str, seed: int) -> Path:
    if seed == 0:
        return ROOT / SEED0_FILES[policy]

    return ROOT / (
        f"W41_OFFICIAL_FIXSR_srRatio{policy}_seed{seed}_8k.log"
    )


def extract_last_metric(lines: list[str], metric: str):
    """提取日志中最后一次直接记录的指标。"""
    patterns = [
        re.compile(
            rf'(?i)["\']?{re.escape(metric)}["\']?'
            rf'\s*[:=]\s*([0-9]+(?:\.[0-9]+)?)'
        ),
        re.compile(
            rf'(?i)\b{re.escape(metric)}\b'
            rf'[^0-9\n]{{0,25}}([0-9]+(?:\.[0-9]+)?)'
        ),
    ]

    for index in range(len(lines) - 1, -1, -1):
        line = lines[index]

        for pattern in patterns:
            match = pattern.search(line)

            if not match:
                continue

            raw_value = float(match.group(1))
            scaled = False

            # 兼容某些日志以0--1小数保存指标。
            if 0.0 <= raw_value <= 1.0:
                raw_value *= 100.0
                scaled = True

            return {
                "value": raw_value,
                "line_no": index + 1,
                "line": line.strip(),
                "scaled": scaled,
            }

    return None


def has_8k_context(lines: list[str], line_no: int) -> bool:
    """确认最终指标附近是否出现8000迭代标记。"""
    index = line_no - 1
    start = max(0, index - 120)
    end = min(len(lines), index + 10)
    block = "\n".join(lines[start:end])

    patterns = [
        r"8000\s*/\s*8000",
        r"iter(?:ation)?[^0-9]{0,20}8000",
        r"\b8000\b",
        r"\b8k\b",
    ]

    return any(re.search(p, block, re.I) for p in patterns)


detail_rows = []
results = {policy: {} for policy in POLICIES}
errors = []

for policy in POLICIES:
    for seed in (0, 1, 2):
        path = build_path(policy, seed)

        if not path.exists():
            errors.append(f"文件不存在：{path}")
            continue

        lines = path.read_text(
            encoding="utf-8",
            errors="ignore",
        ).splitlines()

        miou = extract_last_metric(lines, "mIoU")
        macc = extract_last_metric(lines, "mAcc")
        aacc = extract_last_metric(lines, "aAcc")

        if miou is None:
            errors.append(f"未提取到mIoU：{path}")
            continue

        results[policy][seed] = miou["value"]

        detail_rows.append({
            "policy": policy,
            "seed": seed,
            "mIoU": f"{miou['value']:.4f}",
            "mAcc": (
                f"{macc['value']:.4f}"
                if macc is not None else ""
            ),
            "aAcc": (
                f"{aacc['value']:.4f}"
                if aacc is not None else ""
            ),
            "mIoU_line_no": miou["line_no"],
            "has_8k_context": (
                "yes"
                if has_8k_context(lines, miou["line_no"])
                else "CHECK"
            ),
            "scaled_from_fraction": (
                "yes" if miou["scaled"] else "no"
            ),
            "file": path.name,
            "matched_line": miou["line"],
        })


detail_csv = Path("cityscapes_8k_9policy_3seed_detail.csv")

with detail_csv.open(
    "w",
    newline="",
    encoding="utf-8-sig",
) as file:
    writer = csv.DictWriter(
        file,
        fieldnames=[
            "policy",
            "seed",
            "mIoU",
            "mAcc",
            "aAcc",
            "mIoU_line_no",
            "has_8k_context",
            "scaled_from_fraction",
            "file",
            "matched_line",
        ],
    )
    writer.writeheader()
    writer.writerows(detail_rows)


summary_rows = []

for policy in POLICIES:
    values_by_seed = results[policy]

    if len(values_by_seed) != 3:
        errors.append(
            f"{policy}只提取到{len(values_by_seed)}个seed："
            f"{sorted(values_by_seed)}"
        )
        continue

    values = [
        values_by_seed[0],
        values_by_seed[1],
        values_by_seed[2],
    ]

    mu = mean(values)
    sigma = pstdev(values)
    score = mu - sigma

    summary_rows.append({
        "policy": policy,
        "seed0": f"{values[0]:.2f}",
        "seed1": f"{values[1]:.2f}",
        "seed2": f"{values[2]:.2f}",
        "mean": f"{mu:.2f}",
        "std_ddof0": f"{sigma:.2f}",
        "mean_pm_std": f"{mu:.2f}±{sigma:.2f}",
        "S_mu_minus_sigma": f"{score:.2f}",
    })


summary_csv = Path("cityscapes_8k_9policy_3seed_summary.csv")

with summary_csv.open(
    "w",
    newline="",
    encoding="utf-8-sig",
) as file:
    writer = csv.DictWriter(
        file,
        fieldnames=[
            "policy",
            "seed0",
            "seed1",
            "seed2",
            "mean",
            "std_ddof0",
            "mean_pm_std",
            "S_mu_minus_sigma",
        ],
    )
    writer.writeheader()
    writer.writerows(summary_rows)


print("\n========== Cityscapes 8k FIXSR landscape ==========\n")
print(
    f"{'Policy':<8}"
    f"{'Seed0':>9}"
    f"{'Seed1':>9}"
    f"{'Seed2':>9}"
    f"{'Mean±Std':>16}"
    f"{'S':>9}"
)
print("-" * 60)

for row in summary_rows:
    print(
        f"{row['policy']:<8}"
        f"{row['seed0']:>9}"
        f"{row['seed1']:>9}"
        f"{row['seed2']:>9}"
        f"{row['mean_pm_std']:>16}"
        f"{row['S_mu_minus_sigma']:>9}"
    )

print("\n详细记录：", detail_csv.resolve())
print("汇总结果：", summary_csv.resolve())

if errors:
    print("\n========== 需要人工检查 ==========")
    for error in errors:
        print("-", error)
else:
    print("\n27个实验均已成功提取。")
