_base_ = ['./W36_NW0_PRETRAIN_6211_FIXSR_seed0_160k.py']

seed = 0
randomness = dict(seed=0, deterministic=False)

model = dict(
    backbone=dict(
        sr_ratios=[1, 1, 1, 1],
        linksr_coupling=False,
        linksr_v2_coupling=False,
        linksr_v2_detach_context=False,
    )
)

work_dir = (
    '/data/tmp/ZhangXinHui/segman_outputs/work_dirs/'
    'W42_OFFICIAL_FIXSR_srRatio4211_seed0_160k'
)
exp_name = 'W42_OFFICIAL_FIXSR_srRatio4211_seed0_160k'

runner = dict(
    type='IterBasedRunner',
    max_iters=160000,
)

# 每4万保存一次，但始终只保留最新一个，防止爆空间
checkpoint_config = dict(
    by_epoch=False,
    interval=40000,
    save_last=True,
    max_keep_ckpts=1,
)

evaluation = dict(
    interval=4000,
    metric='mIoU',
    pre_eval=True,
)

resume_from = None


# KBS revision 1111 baseline
seed = 3
randomness = dict(seed=3, deterministic=False)
work_dir = '/data/tmp/ZhangXinHui/kbs_revision_20260923/1111_full160k/work_dirs/seed3'
resume_from = None
