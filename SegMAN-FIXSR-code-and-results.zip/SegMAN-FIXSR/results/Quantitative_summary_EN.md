# Revision additions: target-budget analysis

Old results use the previously submitted archive. Newly completed policies4411,6311,6411,8211,8311 contribute25 target records; earlier1111 controls and4211/4311/6211/8411 contribute25 reference records. All use final160k validation, population std(ddof=0) and S=mean-std. The two supplementary visualization retrains are excluded.

| Policy | n | Mean mIoU | Population std | S | Mean rank | S rank |
|---|---:|---:|---:|---:|---:|---:|
| 4211 | 5 | 80.626 | 0.154 | 80.472 | 6 | 4 |
| 4311 | 5 | 80.750 | 0.181 | 80.569 | 2 | 2 |
| 4411 | 5 | 80.614 | 0.279 | 80.335 | 7 | 6 |
| 6211 | 5 | 80.674 | 0.397 | 80.277 | 4 | 7 |
| 6311 | 5 | 80.602 | 0.426 | 80.176 | 8 | 8 |
| 6411 | 5 | 80.818 | 0.233 | 80.585 | 1 | 1 |
| 8211 | 5 | 80.632 | 0.194 | 80.438 | 5 | 5 |
| 8311 | 5 | 80.690 | 0.189 | 80.501 | 3 | 3 |
| 8411 | 5 | 80.450 | 0.327 | 80.123 | 9 | 9 |

1111 control: mean=80.970, population std=0.227, S=80.743. Control excluded from lattice ranks.

For mean, proxy order: 4211, 4311, 8211, 6211, 8411, 6411, 4411, 8311, 6311. Target order: 6411, 4311, 8311, 6211, 8211, 4211, 4411, 6311, 8411. Spearman rho=0.200000; Kendall tau-b=0.111111. Observed regrets for k=1..9: 0.192000, 0.068000, 0.068000, 0.068000, 0.068000, 0.000000, 0.000000, 0.000000, 0.000000 percentage points.

For S, proxy order: 4211, 8211, 4311, 6211, 8411, 6411, 4411, 8311, 6311. Target order: 6411, 4311, 8311, 4211, 8211, 4411, 6211, 6311, 8411. Spearman rho=0.200000; Kendall tau-b=0.166667. Observed regrets for k=1..9: 0.113722, 0.113722, 0.016019, 0.016019, 0.016019, 0.000000, 0.000000, 0.000000, 0.000000 percentage points.

The old4211 values are80.56,80.87,80.40,80.61,80.69, as in the prior submission; mean=80.626, population std=0.154480, S=80.471520. The older three-repeat mean80.61 and seed3 result80.61 are distinct quantities. Alternative historical server logs differ; the selected original archive and the unresolved discrepancy are documented in docs/SOURCE_SELECTION.md.

These are retrospective observed-score comparisons, not significance tests, paired-seed tests or causal policy effects. Actual random seeds do not always match directory labels. Historical variants remain documented; sensitivity excluding4211 and6211 is available. Resource data are the unchanged previously submitted uniform RTX4090 measurements, not new profiling. The mean-accuracy/latency frontier including control is: 1111, 4411, 6411.
