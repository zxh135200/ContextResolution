# Third-party notices

This repository preserves inherited copyright notices. The root Apache-2.0 software license does not override separately licensed components or external dataset terms. Benchmark-derived outputs do not grant additional rights to the underlying benchmark data.

| Component | Origin | Applicable license/notice |
|---|---|---|
| SegMAN runtime and decoder/backbone base | <https://github.com/yunxiangfu2001/SegMAN> at `ac606438a87d4c4d4b48064df844c86dfbd59958` | Apache-2.0, root `LICENSE` |
| MMSegmentation toolbox | <https://github.com/open-mmlab/mmsegmentation>, version 0.30.0 | Apache-2.0; OpenMMLab headers retained |
| SegFormer `mix_transformer.py` and `segformer_head.py` | <https://github.com/NVlabs/SegFormer> | NVIDIA Source Code License for SegFormer; non-commercial research/evaluation use restriction; `licenses/SegFormer-NVIDIA.txt` |
| Selective-scan/Mamba sources | <https://github.com/state-spaces/mamba> | Apache-2.0; Albert Gu/Tri Dao source notices retained |
| VMamba modifications/scan sources | <https://github.com/MzeroMiko/VMamba> | MIT, `licenses/VMamba-MIT.txt`; MzeroMiko and inherited source notices retained |
| NATTEN and other installed dependencies | See upstream package distributions | Their respective licenses, not relicensed by this repository |

The archived SegMAN study implementation modifies the backbone and adds audit/profiling tools. Modified files carry a prominent notice and are enumerated in `provenance/code.json`.

Cityscapes originals and ADE20K originals are not included. Their access and use conditions remain those of the respective providers. Saved model predictions, experimental logs and source data do not grant rights to mirror the original benchmark images.
